<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



//To Check Page Authentication
function checkAuthLevel($level1 = 0, $level2 = 0, $level3 = 0, $level4 = 0) {
    if ($level1 == 0 && $level2 == 0 && $level3 == 0 && $level4 == 0) {
        redirect(BASEDIR . "home.php");
    } else if ($level1 == $_SESSION['UDP_UserInfo']["user_auth"] || $level2 == $_SESSION['UDP_UserInfo']["user_auth"] || $level3 == $_SESSION['UDP_UserInfo']["user_auth"] || $level4 == $_SESSION['UDP_UserInfo']["user_auth"]) {
        $_SESSION["UDP_UserLevel"] = true;
    } else {
        redirect(BASEDIR . "?dashboard");
    }
}

//Check Uploading file status
function CheckFileStatus($File) {
    $Files = "";
    $fileInfo;
    // Require a file to be attached: false = Do not allow attachments true = allow only 1 file to be attached
    $requirefile = "true";

    // Allowed file types. add file extensions WITHOUT the dot.
    $allowtypes = array("jpg", "jpeg", "png", "gif", "bmp");
    // Maximum file size for attachments in KB NOT Bytes for simplicity. MAKE SURE your php.ini can handel it,
    // post_max_size, upload_max_filesize, file_uploads, max_execution_time!
    // 2048kb = 2MB,       1024kb = 1MB,     512kb = 1/2MB etc..
    $max_file_size = "2048";
    
    
    for ($i = 0; $i < sizeof($File); $i++) {
        $filename = "";
        $errorMessage = "";
        $fileName = rand(1, 100000000) . randLetter();

        if ((!empty($File[$i])) && ($File[$i]['error'] == 0)) { 
            // basename -- Returns filename component of path
            $filename = strtolower(basename($File['name'][$i]));
            echo "<script> alert('{$filename}'); </script>";
            $ext = substr($filename, strrpos($filename, '.') + 1);
            $filesize = $File[$i]['size'];
            $max_bytes = $max_file_size * 1024;
            $fileName = $fileName . "." . $ext;
            //Check if the file type uploaded is a valid file type. 
            if (!in_array($ext, $allowtypes)) {
                $errorMessage .= "<span>Invalid extension for your file: <strong>'" . $filename . "'</strong></span><br />\n";

                // check the size of each file
            } elseif ($filesize > $max_bytes) {
                $errorMessage .= "<span> Your file: <strong>" . $filename . "</strong> is to big. Max file size is '" . $max_file_size . "'kb.</span><br />\n";
            }
        }
        
        $Files[$i]["FileName"] = $filename;
        $Files[$i]["FName"] = $fileName;
        $Files[$i]["FError"] = $errorMessage;
 
 
    }


    return $Files;
}

//Upload files to server
function uploadIt($FILES, $FileInfo, $attr, $attr_name, $directory) {

    if ((!empty($FILES["{$attr_name}"])) && ($FILES["{$attr_name}"]['error'] == 0)) { echo "<script> alert('test {$FILES["{$attr_name}"]}'); </script>";
        $target = $directory . $FileInfo["FName"];
        $attr["{$attr_name}"] = $FileInfo["FName"];
        //Uploading file to img/uaer/ directory
        if (move_uploaded_file($FILES["{$attr_name}"]["tmp_name"], $target)) {
            createThumbs("{$directory}{$FileInfo["FName"]}", "{$directory}{$FileInfo["FName"]}", 400);
            createThumbs("{$directory}{$FileInfo["FName"]}", "{$directory}thumbs/{$FileInfo["FName"]}", 150);
            $errorMessage .= "<center><span>The file {$FileInfo["FileName"]} has been uploaded.</span></center><br />\n";
        } else {
            $errorMessage .= "<span>Sorry, there was a problem uploading your file {$FileInfo["FileName"]}.</span><br />\n";
        }
        
    } else {
        $attr["{$attr_name}"] = $attr["{$attr_name}1"];
    }
    return $target;//$attr["{$attr_name}"];
}

//Create Uploaded Image Thumbnail
function createThumbs($pathToImages, $pathToThumbs, $thumbWidth) {
    // parse path for the extension
    $allowtypes = array("jpg", "jpeg", "png", "gif", "bmp");
    $info = pathinfo($pathToImages);
    // continue only if this is a JPEG image
    if (in_array($info['extension'], $allowtypes)) {
        // load image and get image size
        $img = ""; // imagecreatefromjpeg("{$pathToImages}");

        if ($info['extension'] == 'jpg' || $info['extension'] == 'jpeg')
            $img = imagecreatefromjpeg("{$pathToImages}");
        if ($info['extension'] == 'png')
            $img = imagecreatefrompng("{$pathToImages}");
        if ($info['extension'] == 'gif')
            $img = imagecreatefromgif("{$pathToImages}");
        if ($info['extension'] == 'bmp')
            $img = imagecreatefromwbmp("{$pathToImages}");

        $width = imagesx($img);
        $height = imagesy($img);

        // calculate thumbnail size
        $new_width = $thumbWidth;
        $new_height = floor($height * ( $thumbWidth / $width ));

        // create a new temporary image
        $tmp_img = imagecreatetruecolor($new_width, $new_height);

        // copy and resize old image into new image
        imagecopyresized($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

        // save thumbnail into a file

        if ($info['extension'] == 'jpg' || $info['extension'] == 'jpeg')
            imagejpeg($tmp_img, "{$pathToThumbs}");
        if ($info['extension'] == 'png')
            imagepng($tmp_img, "{$pathToThumbs}");
        if ($info['extension'] == 'gif')
            imagegif($tmp_img, "{$pathToThumbs}");
        if ($info['extension'] == 'bmp')
            imagewbmp($tmp_img, "{$pathToThumbs}");
    }
}

function UploadImages($FILES, $attr, $dir, $index = 0, $watermark = "no"){
    $target_dir = $dir;
    $target_file = $target_dir . basename($FILES["$attr"]["name"][$index]);
    $uploadOk = 1;
    $errorMessage = "";
    
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
    $fileName = (!empty($imageFileType)) ? rand(1, 100000000) . randLetter().".".$imageFileType : "";
//    $_SESSION['er'] .= "filename - ".$attr . " - dir -".$dir. ' target file '.$target_file;
// Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "mp3" && $imageFileType != "ogg" && $imageFileType != "wav" &&  $imageFileType != "mid"  ) {
        //$errorMessage .= "Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br />";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        //$errorMessage .= "Sorry, your image file was not uploaded.<br />";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($FILES["$attr"]["tmp_name"][$index], $target_dir.$fileName)) {
            if($watermark == "yes"){
                // Load the stamp and the photo to apply the watermark to
                $stamp = imagecreatefrompng(HostRoot.'logo.png');
                $im = imagecreatefromjpeg($target_dir.$fileName);
                // Set the margins for the stamp and get the height/width of the stamp image
                $marge_right = 10;//rand(10, 500);
                $marge_bottom = 10;//rand(10, 500);
                $sx = imagesx($stamp);
                $sy = imagesy($stamp);
                // Copy the stamp image onto our photo using the margin offsets and the photo 
                // width to calculate positioning of the stamp. 
                imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));

                // Output and free memory
                header('Content-type: image/jpeg');
                imagejpeg($im);

                imagejpeg($im, $target_dir.$fileName , 90);

                imagedestroy($im);
            }
            createThumbs($target_dir.$fileName, $target_dir."thumbs/".$fileName, 500);
        } else {
             $errorMessage .= "Sorry, there was an error uploading your file.";
        }
        
    }
    
     if (!empty($errorMessage)) {
        $_SESSION["er"] = $errorMessage;
        $fileName = "";
     }
     
    return $fileName;
}

//Get Image Ext wise Icon
function getThumbnail($ext) {
    $data = "";
    switch (strtolower($ext)) {
        case "jpg" :
            $data = "jpeg-icon.png";
            break;
        case "jpeg" :
            $data = "jpeg-icon.png";
            break;
        case "png" :
            $data = "jpeg-icon.png";
            break;
        case "gif" :
            $data = "jpeg-icon.png";
            break;
        case "bmp" :
            $data = "jpeg-icon.png";
            break;
        case "pdf" :
            $data = "pdf.png";
            break;
        case "doc" :
            $data = "doc.png";
            break;
        case "docx" :
            $data = "doc.png";
            break;
        default :
            $data = (!empty($ext)) ? "jpeg-icon.png" : "";
            break;
    }
    return $data;
}

//Print Session Message on Page Top
function getSessionMsg() {
    $data = ""; 
    if (!empty($_SESSION['er'])) {
        $data .= "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><i class='fa fa-remove pr10'></i>{$_SESSION['er']}</div>";
        unset($_SESSION['er']);
    }if (!empty($_SESSION['su'])) {
        $data .= "<div class='alert alert-success alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><i class='fa fa-check pr10'></i>{$_SESSION['su']}</div>";
        unset($_SESSION['su']);
    }if (!empty($_SESSION['note'])) {
        $data .= "<div class='alert alert-warning alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><i class='fa fa-warning pr10'></i>{$_SESSION['note']}</div>";
        unset($_SESSION['note']);
    }
    return $data;
}

//On page view hit counter
function initCounter() {

    $ip = $_SERVER['REMOTE_ADDR']; //get visitor ip
    $location = $_SERVER['PHP_SELF']; //get server file path
    $sid = session_id();
    $qry_1 = "INSERT INTO counter(session_id, ip, location)VALUES('$sid', '$ip', '$location') ON DUPLICATE KEY UPDATE location='$location' ";
    //create log in database table 'counter'
    $create_log = mysql_query($qry_1);
}

//Get Hit counter SUM value
function getCounter() {

    $get_res = mysql_query("SELECT session_id FROM counter");

    $res = mysql_num_rows($get_res);

    return $res;
}

//Update User Activity Time
function hitUserActivity() {
    mysql_query("UPDATE `" . PREFIX . "_user_info_tb` SET `user_activity` = NOW(), `user_logout` = '' WHERE `user_id` = " . USERID);
}

//Get User Last Activity Time
function getUserActivity() {
    $result = mysql_query("SELECT TIME_FORMAT(TIMEDIFF(time(now()), `user_activity`),'%H:%I') AS diff FROM `" . PREFIX . "_user_info_tb` WHERE `user_id` = " . USERID . " LIMIT 0,1");
    $rw = mysql_fetch_array($result);
    return $rw["diff"];
}

//Update User Logout Time
function setUserLogoutTime() {
    mysql_query("UPDATE `" . PREFIX . "_user_info_tb` SET `user_logout` = NOW() WHERE `user_id` = " . USERID);
}

//Get Login System IP
function getIp() {

    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    return $ip;
}

//Check Login Username And Password
function doLogin($POST) {
    $userName = strip_tags($_POST["username"]);
    $passWord = strip_tags($_POST["password"]);
    $qry_1 = "select * from `user_info_tb` where `user_status` = 1 and `user_name`='{$userName}' and `user_password`='" . encode($passWord) . "'"; // and `user_password`='" . encode($passWord) . "'
    $result = mysql_query($qry_1);
    if (mysql_num_rows($result) == 1) {
        
        $rw = mysql_fetch_array($result);
        //if($rw["user_logout"] != '0000-00-00 00:00:00'){
        $_SESSION['LBT_USER'] = $rw;
        unset($_SESSION['er']);
        mysql_query("UPDATE `user_log_tb` SET `user_last_login` = NOW(), `user_logout` = '' WHERE `user_id` = {$rw["user_id"]}");
        $_SESSION['su'] = "Welcome! <strong>" . $rw["user_full_name"] . "</strong> to Admin Dashboard.";
        redirect(HostRoot."dashboard");
        ///Setting Cookie
//        $year = time() + 31536000;
//        if($POST['remember']) {
//            setcookie('remember_me', $userName, $year);
//        }
//        elseif(!$POST['remember']) {
//            if(isset($_COOKIE['remember_me'])) {
//                $past = time() - 100;
//                setcookie(remember_me, gone, $past);
//            }
//        }
        
        /* }elseif($rw["user_logout"] == '0000-00-00 00:00:00'){
          $_SESSION['er'] = "Not able to login. Another Session is in active Mode";
          redirect("./login.php");
          } */
    } else {
        $_SESSION['er'] = "Invalid Username/Password!...";
        redirect(HostRoot."login");
    }
}

//Get Authentication Name
function getAuthName($ID) {
    $authName = array("", "Administrator", "Employee");
    return $authName[$ID];
}

//Get Authentication List View
function getAuthSelectList($status) {
    $data = ($status == 1) ? "<option value='1' selected>" . getAuthName(1) . "</option>" : "<option value='1'>" . getAuthName(1) . "</option>";
    $data .= ($status == 2) ? "<option value='2' selected>" . getAuthName(2) . "</option>" : "<option value='2'>" . getAuthName(2) . "</option>";
   
    return $data;
}

//Get Authentication Name
function getCatTypeName($ID) {
    $authName = array("", "Gallery", "Events");
    return $authName[$ID];
}

//Get Authentication List View
function getCategoryTypeList($status) {
    $data = ($status == 1) ? "<option value='1' selected>" . getCatTypeName(1) . "</option>" : "<option value='1'>" . getCatTypeName(1) . "</option>";
    $data .= ($status == 2) ? "<option value='2' selected>" . getCatTypeName(2) . "</option>" : "<option value='2'>" . getCatTypeName(2) . "</option>";
   
    return $data;
}


//Get Authentication Name
function getCategoryName($ID) {
    $CatName = array("", "News and Events", "Cultural Programs", "Social Programs");
    return $CatName[$ID];
}

//Get Authentication List View
function getNewsCategorySelectList($id) {
    $data = ($id == 1) ? "<option value='1' selected>" . getCategoryName(1) . "</option>" : "<option value='1'>" . getCategoryName(1) . "</option>";
    $data .= ($id == 2) ? "<option value='2' selected>" . getCategoryName(2) . "</option>" : "<option value='2'>" . getCategoryName(2) . "</option>";
    $data .= ($id == 3) ? "<option value='3' selected>" . getCategoryName(3) . "</option>" : "<option value='3'>" . getCategoryName(3) . "</option>";
   
    return $data;
}

function getTranStatusInfo($ID){
    $data = array("Failure", "Pending", "Paid");
    return $data[$ID];
}

//Get Status Info 
function getStatusInfo($ID) {
    $data = array("Deleted", "Active", "Deactivated");
    return $data[$ID];
}

//Get Status Select List View
function getStatusSelectList($status) {
    $data = ($status == 0) ? "<option value='0' selected>" . getStatusInfo(0) . "</option>" : "<option value=0>" . getStatusInfo(0) . "</option>";
    $data .= ($status == 1) ? "<option value='1' selected>" . getStatusInfo(1) . "</option>" : "<option value='1'>" . getStatusInfo(1) . "</option>";
    $data .= ($status == 2) ? "<option value='2' selected>" . getStatusInfo(2) . "</option>" : "<option value='2'>" . getStatusInfo(2) . "</option>";
    return $data;
}



//Get Attendance List
function getAttendaceStatus($ID) {
    $CatName = array("", "Present", "Absent");
    return $CatName[$ID];
}

//Get Authentication List View
function getAttendanceSelectList($id) {
    $data = ($id == 1) ? "<option value='1' selected>" . getAttendaceStatus(1) . "</option>" : "<option value='1'>" . getAttendaceStatus(1) . "</option>";
    $data .= ($id == 2) ? "<option value='2' selected>" . getAttendaceStatus(2) . "</option>" : "<option value='2'>" . getAttendaceStatus(2) . "</option>";
    
   
    return $data;
}

function getValidityList($id){
    $data = array(0=>"Select Validity",1=>"1 Month",2=>"2 Month",3=>"3 Month",4=>"4 Month",5=>"5 Month",6=>"6 Month",7=>"7 Month",8=>"8 Month",9=>"9 Month",10=>"10 Month",11=>"11 Month",12=>"1 Year",24=>"2 Year",36=>"3 Year");
    return (!empty($id)) ? $data[$id] : $data;
}


function getTalukNameSelectList($id){
    $data = "";
    $_qry = "SELECT * FROM `taluk_tb`";
    $result = mysql_query($_qry);
    while ($rw = mysql_fetch_array($result)){
          $data .= ($id == $rw["taluk_id"]) ? "<option value='{$rw["taluk_id"]}' selected>{$rw["taluk_name"]}</option>" : "<option value='{$rw["taluk_id"]}' selected>{$rw["taluk_name"]}</option>";  
        }
    return $data;
}
function gethobaliSelectList($id){
    $data = "";
    $_qry = "SELECT * FROM `hobli_tb`";
    $result = mysql_query($_qry);
    while ($rw = mysql_fetch_array($result)){
          $data .= ($id == $rw["hobli_id"]) ? "<option value='{$rw["hobli_id"]}' selected>{$rw["hobli_name"]}</option>" : "<option value='{$rw["hobli_id"]}' selected>{$rw["hobli_name"]}</option>";  
        }
    return $data;
}

