<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

mysql_query("CREATE DATABASE IF NOT EXISTS `{$db_name}`");
$db_select = @mysql_select_db($db_name);

// 1th Table
$tb = "CREATE TABLE `{$db_name}`.`user_info_tb` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_full_name` varchar(200) NOT NULL,
  `user_designation` varchar(200) NOT NULL,
  `user_counter` int(11) NOT NULL,
  `user_level` int(11) NOT NULL DEFAULT '2' COMMENT '1=Admin, 2=Counter User',
  `user_status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Inactive, 0=Trashed',
  `user_created_on` datetime NOT NULL,
  `user_updated_on` datetime NOT NULL,
  `user_last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_activity` time NOT NULL,
  `user_logout` datetime NOT NULL,
  `user_ip` varchar(15) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
mysql_query($tb);

$qry_1 = "INSERT INTO `{$db_name}`.`user_info_tb`(`user_name`,`user_password`,`user_full_name`,`user_designation`,`user_level`,`user_created_on`) VALUES('admin','xw_ag5kBnZOk07vnYrXWpVTm-DMxP1gUOQR9fd_ADB8','Administrator','Admin','1',NOW())";
mysql_query($qry_1);

$qry_1 = "CREATE PROCEDURE `toDoUserAction`(IN `usr_id` INT, IN `username` VARCHAR(100), IN `user_password` VARCHAR(150), IN `user_full_name` VARCHAR(250), IN `user_level` INT, IN `process_by` INT) BEGIN IF (usr_id = '') THEN INSERT INTO `user_info_tb` (`user_name`, `user_password`, `user_full_name`, `user_level`, `user_created_on`, `user_updated_on`) VALUES (username, user_password, user_full_name, user_level, NOW(), NOW()); ELSE UPDATE `user_info_tb` SET `user_name` = username, `user_password` = user_password, `user_full_name` = user_full_name, `user_level` = user_level, `user_updated_on` = NOW() WHERE `user_id` = usr_id; END IF; END";
mysql_query($qry_1);

$qry_1 = "CREATE PROCEDURE `updateUserStatus`(IN `usr_id` INT, IN `usr_status` INT) BEGIN UPDATE `user_info_tb` SET `user_status` = usr_status, `user_updated_on` = NOW() WHERE `user_id` = usr_id; END";
mysql_query($qry_1);


// Taluk Table
$tb = "CREATE TABLE `{$db_name}`.`taluk_tb` (
  `taluk_id` int(11) NOT NULL AUTO_INCREMENT,
  `taluk_name` varchar(100) NOT NULL,
  `taluk_status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Inactive, 0=Trashed',
  PRIMARY KEY (`taluk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
mysql_query($tb);

// Hobli Table
$tb = "CREATE TABLE `{$db_name}`.`hobli_tb` (
  `hobli_id` int(11) NOT NULL AUTO_INCREMENT,
  `hobli_taluk_id` int(11) NOT NULL,
  `hobli_name` varchar(100) NOT NULL,
  `hobli_status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Inactive, 0=Trashed',
  PRIMARY KEY (`hobli_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
mysql_query($tb);

// Jilla Panchayat Table
$tb = "CREATE TABLE `{$db_name}`.`jilla_panchayat_tb` (
  `jp_id` int(11) NOT NULL AUTO_INCREMENT,
  `jp_taluk_id` int(11) NOT NULL,
  `jp_hobli_id` int(11) NOT NULL,
  `jp_name` varchar(100) NOT NULL,
  `jp_status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Inactive, 0=Trashed',
  PRIMARY KEY (`jp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
mysql_query($tb);

// Village Table
$tb = "CREATE TABLE `{$db_name}`.`village_tb` (
  `village_id` int(11) NOT NULL AUTO_INCREMENT,
  `village_taluk_id` int(11) NOT NULL,
  `village_hobli_id` int(11) NOT NULL,
  `village_jp_id` int(11) NOT NULL,
  `village_name` varchar(100) NOT NULL,
  `village_status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Inactive, 0=Trashed',
  PRIMARY KEY (`village_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
mysql_query($tb);

// entry_form Table
$tb = "CREATE TABLE `{$db_name}`.`entry_form_tb` (
  `ef_id` int(11) NOT NULL AUTO_INCREMENT,
  `ef_name` varchar(100) NOT NULL,
  `ef_photo` varchar(20) NOT NULL,
  `ef_age` varchar(50) NOT NULL,
  `ef_sex` varchar(50) NOT NULL,
  `ef_cast` varchar(100) NOT NULL,
  `ef_dob` varchar(100) NOT NULL,
  `ef_fathername` varchar(100) NOT NULL,
  `ef_fatheroccupation` varchar(100) NOT NULL,
  `ef_mothername` varchar(100) NOT NULL,
  `ef_motheroccupation` varchar(100) NOT NULL,
  `ef_contact` varchar(50) NOT NULL,
  `ef_present_address` varchar(200) NOT NULL,
  `ef_permanent_address` varchar(200) NOT NULL,
  `ef_study_class` varchar(100) NOT NULL,
  `ef_teacher_name` varchar(100) NOT NULL,
  `ef_teacher_contact` varchar(50) NOT NULL,
  `ef_headmaster_name` varchar(100) NOT NULL,
  `ef_school_address` varchar(200) NOT NULL,
  `ef_quit_class` varchar(100) NOT NULL,
  `ef_joined_status` varchar(50) NOT NULL,
  `ef_numberofdays` varchar(50) NOT NULL,
  `ef_immigrationfrom` varchar(100) NOT NULL,
  `ef_staying_days` varchar(50) NOT NULL,
  `ef_gotower` varchar(100) NOT NULL,
  `ef_stepstobetaken` varchar(200) NOT NULL,
  `ef_status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Inactive, 0=Trashed',
  PRIMARY KEY (`ef_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
mysql_query($tb);

$qry_1 = "CREATE PROCEDURE `toDoEntryFormAction`(IN `efid` INT, IN `efname` VARCHAR(100), IN `efphoto` VARCHAR(20), IN `efage` VARCHAR(50), IN `efsex` VARCHAR(50), IN `efcast` VARCHAR(100), IN efdob VARCHAR(100), IN effathername VARCHAR(100), IN effatheroccup VARCHAR(100), IN efmothername VARCHAR(100), IN efmotheroccup VARCHAR(100), IN efcontact VARCHAR(50), IN efpresentaddress VARCHAR(200), IN efpermanentaddress VARCHAR(200), IN efstudyclass VARCHAR(100), IN efteachrname VARCHAR(100), IN efteachercontct VARCHAR(50), IN efheadmaster VARCHAR(100), IN efaddress VARCHAR(200), IN efquitclass VARCHAR(100), IN efjoinedstatus VARCHAR(50), IN efnumbrofdays VARCHAR(50), IN efimmigrate VARCHAR(100), IN efstay VARCHAR(50), IN efgone VARCHAR(100), IN steptaken VARCHAR(200)) BEGIN IF (efid = '') THEN INSERT INTO `entry_form_tb` (`ef_name`, `ef_photo`, `ef_age`, `ef_sex`, `ef_cast`, `ef_dob`, `ef_fathername`, `ef_fatheroccupation`, `ef_mothername`, `ef_motheroccupation`, `ef_contact`, `ef_present_address`, `ef_permanent_address`, `ef_study_class`, `ef_techer_name`, `ef_teacher_contact`, `ef_headmaster_name`, `ef_school_address`, `ef_quit_class`, `ef_joined_status`, `ef_numberofdays`, `ef_immigrationfrom`, `ef_staying_days`, `ef_gotower`, `ef_stepstobetaken`) VALUES (efname, efphoto, efage, efsex, efcast, efdob, effathername, effatheroccup, efmothername, efmotheroccup, efcontact, efpresentaddress, efpermanentaddress, efstudyclass, efteachrname, efteachercontct, efheadmaster, efaddress, efquitclass, efjoinedstatus, efnumbrofdays, efimmigrate, efstay, efgone, steptaken); ELSE UPDATE `entry_form_tb` SET `ef_name` = efname, `ef_photo` = efphoto, `ef_age` = efage, `ef_sex` = efsex, `ef_cast` = efcast, `ef_dob` = efdob, `ef_fathername` = effathername, `ef_fatheroccupation` = effatheroccup, `ef_mothername` = efmothername, `ef_motheroccupation` = efmotheroccup, `ef_contact` = efcontact, `ef_present_address` = efpresentaddress, `ef_permanent_address` = efpermanentaddress, `ef_study_class` = efstudyclass, `ef_techer_name` = efteachrname, `ef_teacher_contact` = efteachercontct, `ef_headmaster_name` = efheadmaster, `ef_school_address` = efaddress, `ef_quit_class` = efquitclass, `ef_joined_status` = efjoinedstatus, `ef_numberofdays` = efnumbrofdays, `ef_immigrationfrom` = efimmigrate, `ef_staying_days` = efstay, `ef_gotower` = efgone, `ef_stepstobetaken` = steptaken WHERE `ef_id` = efid; END IF; END";
mysql_query($qry_1);

$qry_1 = "CREATE PROCEDURE `updateEntryFormStatus`(IN `efid` INT, IN `efstatus` INT) BEGIN UPDATE `entry_form_tb` SET `ef_status` = efstatus WHERE `ef_id` = efid; END";
mysql_query($qry_1);



if(mysql_errno()){
    $_SESSION["er"]=  mysql_error();
}


redirect(HostRoot);
