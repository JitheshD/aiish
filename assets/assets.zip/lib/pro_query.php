<?php 
//
//
/////////////////////////////////////////////////////////////
//// User Page Start
///////////////////////////////////////////////////////////

function ToDoUserForm($POST, $GET, $FILES){
    $formData = $qry_1 = "";
    $status = FALSE;
    
    if(isset($POST["SubmitUser"])){
        $usr_id = strip_tags($POST["user_id"]);
        $usr_name = strip_tags($POST["username"]);
        $usr_password = encode(strip_tags($POST["password"]));
        $usr_full_name = strip_tags($POST["full_name"]);
        $usr_level = strip_tags($POST["user_level"]);
        $qry_1 =  "CALL toDoUserAction('{$usr_id}', '{$usr_name}', '{$usr_password}', '{$usr_full_name}', '{$usr_level}', '".$_SESSION['LBT_USER']["user_id"]."')";
        //mysql_query($qry_1);
        
        $status = TRUE;
    }else if(isset($GET["user"]) && is_numeric(decode($GET["user"])) && isset($GET["st"]) && is_numeric($GET["st"])){
        $st = strip_tags($GET["st"]);
        $usr_id = decode($GET["user"]);
        $qry_1 = "CALL updateUserStatus('{$usr_id}','{$st}')";
        //mysql_query($qry_1);
        $status = TRUE;
    }else if( isset($GET["user"]) && is_numeric(decode($GET["user"])) && !isset($GET["st"]) ){
        $id =  decode($GET["user"]);
        $formData = getUserByID($id);
        $status = FALSE;
    }    
    
    
    if($status){
        mysql_query($qry_1);
        if(mysql_errno()){ $_SESSION["er"] = "Unexpected Error found while processing this task....".$qry_1; }
        else{ $_SESSION["su"] = "Task Completed ...."; }
        redirect(HostRoot."user");
    }
    return $formData;
}


function getUserList(){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT * FROM `user_info_tb`");    
    while($value = mysql_fetch_array($result)){
        $ID = encode($value["user_id"]);
        $st = ($value['user_status'] == 1) ? array("st"=>"2", "name"=>"Inactive") : array("st"=>"1", "name"=>"Active");
        $data .= ""
                . "<tr>
                        <td>{$value["user_name"]}</td>
                        <td>{$value["user_full_name"]}</td>
                        <td>".getAuthName($value["user_level"])."</td>
                        <td>".getStatusInfo($value["user_status"])."</td>
                        <td>
                            <a href='".HostRoot."user/{$ID}'><i class='fa fa-gears'></i> Edit</a> &nbsp;|&nbsp;
                            <a href='".HostRoot."user/{$ID}/st/{$st["st"]}'><i class='fa fa-trash-o'></i> {$st["name"]}</a>
                        </td>
                    </tr>";
        $index++;
    }
    return $data;
}

function getUserByID($ID){
    $_qry = "SELECT * FROM `user_info_tb` WHERE `user_id` = '{$ID}'";
    $result = mysql_query($_qry);
    $data = mysql_fetch_assoc($result);
    return $data;
}


//function getUserAttrByID($ID, $attr){
//    $_qry = "SELECT `{$attr}` FROM `user_info_tb` WHERE `user_id` = '{$ID}'";
//    $result = mysql_query($_qry);
//    $data = mysql_fetch_assoc($result);
//    return $data[$attr];
//}

function getUserCount(){
    $qry_1 = "SELECT 
                (select count(*) from user_info_tb where user_status = 1) as ActiveUser,
                (select count(*) from user_info_tb WHERE user_status <> 1) as InactiveUser,
                (select count(*) from user_info_tb) as TotalUser";
    $result = mysql_query($qry_1);
    $rw = mysql_fetch_assoc($result);
    return $rw;
}



//function getMenuCategoryNameByID($id){
//    $qry_1 = "SELECT `mc_cat_name` FROM `menu_category_tb` WHERE `mc_id` = '{$id}' LIMIT 0,1";
//    $result = mysql_query($qry_1);
//    $rw = mysql_fetch_array($result);
//    return $rw["mc_cat_name"];
//}

//////////////////////////////////////////////////////////
//entry Form
/////////////////////////////////////////////////////////
function ToDoEntryForm($POST, $GET, $FILES){
    $formData = $qry_1 = "";
    $status = FALSE;
    if(isset($POST["submitentry_form"])){
        
        $tq = $_SESSION["loc"]["taluk"];
        $gp = $_SESSION["loc"]["gp"];
        $village = $_SESSION["loc"]["village"];
        
        $entyfrm_id = strip_tags($POST["entryform_id"]);
        
        $entyfrm_name = strip_tags($POST["firstName"]);
        
        $photo = UploadImages($FILES, 'std_photo', HostRoot."assets/images/imgfiles/", 0);
        $photo = (empty($photo)) ? $POST["std_photo1"] : $photo;
        
        $student_age = strip_tags($POST["age"]);
        $sex = strip_tags($POST["gender"]);
        $stud_dob = convertToSqlDate(strip_tags($POST["dob"]));
        $stud_religion = strip_tags($POST["religion"]);
        $fathername = strip_tags($POST["father_name"]);
        $father_occup = strip_tags($POST["father_occupation"]);
        $mothername = strip_tags($POST["mother_name"]);
        $mother_occup = strip_tags($POST["mother_occupation"]);
        $phoneno = strip_tags($POST["phone_no"]);
        $addres = strip_tags($POST["address"]);
        $permanent_addres = strip_tags($POST["permanent_address"]);
        $clas = strip_tags($POST["class"]);
        $teachr_name = strip_tags($POST["teacher_name"]);
        $teachr_phone_no = strip_tags($POST["teacher_phone_no"]);
        $hm_name = strip_tags($POST["headmaster_name"]);
        $hm_phone_no = strip_tags($POST["headmaster_phone_no"]);
        $schoolname = strip_tags($POST["school_name"]);
        $schooladd = strip_tags($POST["school_address"]);
        $anganavadicenter = strip_tags($POST["anganavadi_center"]);
        $anganavaditeacher = strip_tags($POST["anganavadi_teacher"]);
        
        
        
        //$quit_school = strip_tags($POST["ef_quit_school"]);
        $quit_school = strip_tags($POST["quitted_school"]);
        $quit_class = strip_tags($POST["quitting_class"]);
        
        $quit_school_name = strip_tags($POST["quitting_school_name"]);
        $quit_date = convertToSqlDate(strip_tags($POST["quitting_date"]));
        $readmition = strip_tags($POST["readmition"]);
        $readmition_school_name = strip_tags($POST["readmition_school_name"]);
        
        $joind = strip_tags($POST["joined"]);
        $numbr_days = strip_tags($POST["days"]);
        $immigrate = strip_tags($POST["immigration"]);
        $stayng = strip_tags($POST["staying"]);
        $wrgng = strip_tags($POST["going"]);
        $stepstobetaken = strip_tags($POST["stepstobetaken"]);
        
        $qry_1 =  "CALL toDoEntryFormAction('{$entyfrm_id}', '{$tq}','{$gp}','{$village}', '{$entyfrm_name}', '{$photo}', '{$student_age}', '{$sex}', '{$stud_religion}', '{$stud_dob}', '{$fathername}', '{$father_occup}', '{$mothername}', '{$mother_occup}', '{$phoneno}', '{$addres}', '{$permanent_addres}', '{$clas}', '{$teachr_name}', '{$teachr_phone_no}', '{$hm_name}','{$hm_phone_no}','{$schoolname}', '{$schooladd}', '{$anganavadicenter}','{$anganavaditeacher}', '{$quit_school}', '{$quit_class}', '{$quit_school_name}','{$quit_date}','{$readmition}','{$readmition_school_name}', '{$joind}','{$numbr_days}', '{$immigrate}', '{$stayng}', '{$wrgng}', '{$stepstobetaken}','".USERID."')";
        //mysql_query($qry_1);
        $status = TRUE;
    }else if(isset($GET["entry_form"]) && is_numeric(decode($GET["entry_form"])) && isset($GET["st"]) && is_numeric($GET["st"])){
        $st = strip_tags($GET["st"]);
        $entyfrm_id = decode($GET["entry_form"]);
        $qry_1 = "CALL updateEntryFormStatus('{$entyfrm_id}','{$st}')";
        //mysql_query($qry_1);
        $status = TRUE;
    }else if( isset($GET["entry_form"]) && is_numeric(decode($GET["entry_form"])) && !isset($GET["st"]) ){
        $id =  decode($GET["entry_form"]);
        $formData = getStudentByID($id);
        $status = FALSE;
    }
    if($status){
        $result = mysql_query($qry_1);
        if(mysql_errno()){
            $_SESSION["er"] = "Unexpected Error found while processing this task....";
            redirect(HostRoot."entry_form");
        }
        else{
            $_SESSION["su"] = "Task Completed ....";
            $rw = mysql_fetch_assoc($result);
            redirect((empty($rw["EID"]))? HostRoot."entry_form" : HostRoot."profile/".encode($rw["EID"]));
        }
        
        
    }
    return $formData;
}

function getStudentProfileList(){
    $data = "";
    
    $qry_1 = "SELECT * FROM `entry_form_tb` order by `ef_id` desc";
    $result = mysql_query($qry_1);
    while($value = mysql_fetch_array($result)){
        $tqname = getTalukByID($value["ef_taluk"]);
        $prefix = substr($tqname, 0,3);
        $ID = encode($value["ef_id"]);
        $st = ($value['ef_status'] == 1) ? array("st"=>"2", "name"=>"Inactive", "icon"=>'fa-trash-o') : array("st"=>"1", "name"=>"Active", "icon"=>'fa-check-square');
        
        $data .= ""
                . "<tr>
                        <td><a href='".HostRoot."profile/{$ID}'>".strtoupper($prefix)."{$value["ef_id"]}</a></td>
                        <td>{$value["ef_name"]}</td>
                        <td>{$value["ef_sex"]}</td>
                        <td>{$value["ef_age"]}</td>
                        <td>{$value["ef_dob"]}</td>
                        <td>{$value["ef_cast"]}</td>
                        <td>{$value["ef_fathername"]}</td>
                        <td>{$value["ef_contact"]}</td>
                        <td>
                            <a href='".HostRoot."entry_form/{$ID}'><i class='fa fa-gears'></i> Edit</a> &nbsp;|&nbsp;
                            <a href='".HostRoot."student_report/{$ID}/st/{$st["st"]}'><i class='fa fa-trash-o'></i> {$st["name"]}</a>
                        </td>
                    </tr>";
        
    }
    return $data;
}


function getStudentByID($ID){
    $_qry = "SELECT * FROM `entry_form_tb` WHERE `ef_id` = '{$ID}'";
    $result = mysql_query($_qry);
    $data = mysql_fetch_assoc($result);
    return $data;
}

// Get Taluk Name List
function getTalukSelectList($tqid = 0){
    $data = (empty($tqid))  ? "<option value=''>Select Taluk</option>" : "";
    $qry_1 = "SELECT * FROM `taluk_tb` WHERE `taluk_status` = 1";
    $result = mysql_query($qry_1);
    while($rw = mysql_fetch_array($result)){
        $selected = ($tqid == $rw["taluk_id"]) ? "selected" : "";
        $data .= "<option value='{$rw["taluk_id"]}'>{$rw["taluk_name"]}</option>";
    }
    return $data;
}

// Get Taluk Hobali List
function getTalukHobaliSelectList($tqid = "", $hobali_id=0){
    $data = (empty($hobali_id))  ? "<option value=''>Select Hobali</option>" : "";
    $query = (!empty($tqid)) ? " AND `hobli_taluk_id` = '{$tqid}'" : "";
    $qry_1 = "SELECT * FROM `hobali_tb` WHERE `hobali_status` = 1 {$query}";
    $result = mysql_query($qry_1);
    while($rw = mysql_fetch_array($result)){
        $selected = ($hobali_id == $rw["hobali_id"]) ? "selected" : "";
        $data .= "<option value='{$rw["hobali_id"]}'>{$rw["hobali_name"]}</option>";
    }
    return $data;
}

// Get Hobali Grama Panchayath List
function getHobaliGPSelectList($tqid = "", $hobali_id="", $gp_id = 0){
    $data = (empty($gp_id))  ? "<option value=''>Select Grama Panchayath</option>" : "";
    $query = (!empty($tqid)) ? " AND `jp_taluk_id` = '{$tqid}'" : "";
    $query .= (!empty($hobali_id)) ? " AND `jp_hobali_id` = '{$hobali_id}'" : "";
    $qry_1 = "SELECT * FROM `jilla_panchayat_tb` WHERE `jp_status` = 1 {$query}";
    $result = mysql_query($qry_1);
    while($rw = mysql_fetch_array($result)){
        $selected = ($gp_id == $rw["jp_id"]) ? "selected" : "";
        $data .= "<option value='{$rw["jp_id"]}'>{$rw["jp_name"]}</option>";
    }
    return $data;
}

// Get Grama Panchayath Village List
function getGPVillageSelectList($tqid = "", $hobali_id="", $gp_id = "", $vl_id = 0){
    $data = (empty($vl_id))  ? "<option value=''>Select Village</option>" : "";
    $query = (!empty($tqid)) ? " AND `village_taluk_id` = '{$tqid}'" : "";
    $query .= (!empty($hobali_id)) ? " AND `village_hobali_id` = '{$hobali_id}'" : "";
    $query .= (!empty($gp_id)) ? " AND `village_jp_id` = '{$gp_id}'" : "";
    $qry_1 = "SELECT * FROM `village_tb` WHERE `village_status` = 1 {$query}";
    $result = mysql_query($qry_1);
    while($rw = mysql_fetch_array($result)){
        $selected = ($vl_id == $rw["village_id"]) ? "selected" : "";
        $data .= "<option value='{$rw["village_id"]}'>{$rw["village_name"]}</option>";
    }
    return $data;
}

///////////////////////
//Taluk
////////////////
function getTalukList(){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT * FROM `taluk_tb`");    
    while($value = mysql_fetch_array($result)){
        $ID = encode($value["taluk_id"]);
        $st = ($value['taluk_status'] == 1) ? array("st"=>"2", "name"=>"Inactive") : array("st"=>"1", "name"=>"Active");
        $data .= ""
                . "<tr>
                        <td>{$value["taluk_name"]}</td>
                        <td>".getStatusInfo($value["taluk_status"])."</td>
                        <td>
                </tr>";        
//                            <a href='".HostRoot."taluk/{$ID}'><i class='fa fa-gears'></i> Edit</a> &nbsp;|&nbsp;
//                            <a href='".HostRoot."taluk/{$ID}/st/{$st["st"]}'><i class='fa fa-trash-o'></i> {$st["name"]}</a>
//                        </td>
                    
        $index++;
    }
    return $data;
}

function getTalukByID($ID){
    $_qry = "SELECT `taluk_name` FROM `taluk_tb` WHERE `taluk_id` = '{$ID}'";
    $result = mysql_query($_qry);
    $data = mysql_fetch_assoc($result);
    return $data["taluk_name"];
}





///////////////////////
//hobli
////////////////
function getHobliList(){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT * FROM `hobli_tb`");    
    while($value = mysql_fetch_array($result)){
        $ID = encode($value["hobli_id"]);
        $st = ($value['hobli_status'] == 1) ? array("st"=>"2", "name"=>"Inactive") : array("st"=>"1", "name"=>"Active");
        $data .= ""
                . "<tr>
                        <td>{$value["hobli_name"]}</td>
                        <td>".getTalukByID($value[hobli_taluk_id])."</td>
                        <td>".getStatusInfo($value["hobli_status"])."</td>
                </tr>";
//                        <td>
//                            <a href='".HostRoot."hobli/{$ID}'><i class='fa fa-gears'></i> Edit</a> &nbsp;|&nbsp;
//                            <a href='".HostRoot."hobli/{$ID}/st/{$st["st"]}'><i class='fa fa-trash-o'></i> {$st["name"]}</a>
//                        </td>
                    
        $index++;
    }
    return $data;
}

function getHobliByID($id){
    $_qry = "SELECT `hobli_name` FROM `hobli_tb` WHERE `hobli_id` = '{$id}'";
    $result = mysql_query($_qry);
    $rw = mysql_fetch_array($result);
    return $rw["hobli_name"];
}

///////////////////////
//Panchayat
////////////////
function getPachayatList(){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT * FROM `jilla_panchayat_tb`");    
    while($value = mysql_fetch_array($result)){
        $ID = encode($value["jp_id"]);
        $st = ($value['jp_status'] == 1) ? array("st"=>"2", "name"=>"Inactive") : array("st"=>"1", "name"=>"Active");
        $data .= ""
                . "<tr>
                        <td>{$value["jp_name"]}</td>
                        <td>".  getHobliByID($value[jp_hobli_id])."</td>
                        <td>".getTalukByID($value[jp_taluk_id])."</td>
                        <td>".getStatusInfo($value["jp_status"])."</td>
                </tr>";            
//                        <td>
//                            <a href='".HostRoot."grama_panchayat/{$ID}'><i class='fa fa-gears'></i> Edit</a> &nbsp;|&nbsp;
//                            <a href='".HostRoot."grama_panchayat/{$ID}/st/{$st["st"]}'><i class='fa fa-trash-o'></i> {$st["name"]}</a>
//                        </td>
                    
        $index++;
    }
    return $data;
}

function getPachayatByID($id){
    $_qry = "SELECT `jp_name` FROM `jilla_panchayat_tb` WHERE `jp_id` = '{$id}'";
    $result = mysql_query($_qry);
    $rw = mysql_fetch_array($result);
    return $rw["jp_name"];
}

///////////////////////
//Village
////////////////
function getVillageList(){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT * FROM `village_tb`");    
    while($value = mysql_fetch_array($result)){
        $ID = encode($value["village_id"]);
        $st = ($value['village_status'] == 1) ? array("st"=>"2", "name"=>"Inactive") : array("st"=>"1", "name"=>"Active");
        $data .= ""
                . "<tr>
                        <td>{$value["village_name"]}</td>
                        <td>". getPachayatByID($value["village_jp_id"])."</td>
                        <td>".  getHobliByID($value["village_hobli_id"])."</td>
                        <td>".getTalukByID($value["village_taluk_id"])."</td>
                        <td>".getStatusInfo($value["village_status"])."</td>
                </tr>";            
//                        <td>
//                            <a href='".HostRoot."village/{$ID}'><i class='fa fa-gears'></i> Edit</a> &nbsp;|&nbsp;
//                            <a href='".HostRoot."village/{$ID}/st/{$st["st"]}'><i class='fa fa-trash-o'></i> {$st["name"]}</a>
//                        </td>
        $index++;
    }
    return $data;
}

function getVillageByID($id){
    $_qry = "SELECT `village_name` FROM `village_tb` WHERE `village_id` = '{$id}'";
    $result = mysql_query($_qry);
    $rw = mysql_fetch_array($result);
    return $rw["village_name"];
}

//Attendance Form

function getSchoolNameList(){
    $data = "";$index = 1;
    $qry_1 = "SELECT DISTINCT `ef_school_name` FROM `entry_form_tb`";
    $result = mysql_query($qry_1);
    while($rw = mysql_fetch_array($result)){
         $data .= "<option value='{$rw["ef_school_name"]}'>{$rw["ef_id"]}{$rw["ef_school_name"]}</option>";
         $index++;
    }
    
    return $data;
}


function getSchoolName($school){
    $data = "";
    foreach ($school as $names)
    {
            $school_name = ($names) ? ($names) : "";
//            echo "$school_name";
           $data .=  getStudentList($school_name);
    }
    return $data;
}


function getGiveAttendance($school, $datecount){
    $data = "";
    
    echo "<script>alert($school)</script>";
    $result = mysql_query("SELECT * FROM `entry_form_tb` WHERE `ef_school_name` = '{$school}'");
    while($value = mysql_fetch_array($result)){
    $data .= ""
                . "<tr>
                        
                        <td>{$value["ef_name"]}</td>
                        
                </tr>";            
   }
    return $data;
}


function  getStudentList($school, $DRange){
//    echo "<script>alert($school)</script>";
    $data = "";
    $result = mysql_query("SELECT * FROM `entry_form_tb` WHERE `ef_school_name` = '{$school}'");
    //$_qry = "SELECT `ef_name` FROM `entry_form_tb` WHERE `ef_school_name` = '{$school}'";
//    $result = mysql_query($_qry);
    while($value = mysql_fetch_array($result)){
        
        $data .= "<tr><td>".$value["ef_name"]."</td>";
        foreach ($DRange as $val){
            $setDate = date("d-m-Y", strtotime($val));
            $tag_id = "std_".$value['ef_id'].$setDate;
            $data .= "<td> <select name='attend_status' id='{$tag_id}' onchange='setAttendance(\"{$value['ef_id']}\",\"{$setDate}\");'> ".getAttendanceSelectList()."</select> </td>";
        }
        $data .= "</tr>";
    }
//    $rw = mysql_fetch_array($result);
    return $data;
}


function ToDoTest2Action($POST, $GET, $FILES){
    $formData = "";
    $status = FALSE;
    
    
    if(isset($POST["SubmitCuisines"])){
        $usr_id = strip_tags($POST["user_id"]);
        $usr_name = strip_tags($POST["username"]);
        $usr_password = encode(strip_tags($POST["password"]));
        $usr_full_name = strip_tags($POST["full_name"]);
        $usr_level = strip_tags($POST["user_level"]);
        
        $qry_1 =  "CALL toDoUserAction('{$usr_id}', '{$usr_name}', '{$usr_password}', '{$usr_full_name}', '{$usr_level}', '".$_SESSION['LBT_USER']["user_id"]."')";
       
        $status = TRUE;
    }elseif(isset($GET["cuisines"]) && is_numeric(decode($GET["cuisines"])) && isset($GET["st"]) && is_numeric($GET["st"])){
        $st = strip_tags($GET["st"]);
        $id = decode($GET["cuisines"]);
        
        $qry_1 = "CALL updateCuisinesStatus('{$id}','{$st}')";
        
        $status = TRUE;
    }elseif( isset($GET["cuisines"]) && is_numeric(decode($GET["cuisines"])) && !isset($GET["st"]) ){
        $id =  decode($GET["cuisines"]);
        $formData = getCuisinesByID($id);
        $status = FALSE;
    }
    if($status){
        mysql_query($qry_1);
        if(mysql_errno()){
            $_SESSION["er"] = "Not able to process your request, Some thing went wrong!...";
        }else{
            $_SESSION["su"] = "Task Completed Successfully";
        }
        redirect(BASEDIR."cuisines");
    }
    return $formData;
}


///////////////////////
//Abssent Report
////////////////
function getAbsentReport($year){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT  `attendance_date` , COUNT( * ) ,  `attendance_std_id` FROM  `attendance_tb` WHERE DATE_FORMAT(  `attendance_date` ,  '%Y' ) =  '{$year}' GROUP BY  `attendance_std_id` , DATE_FORMAT(  `attendance_date` ,  '%Y%m' ) LIMIT 0 , 30");    
    while($value = mysql_fetch_array($result)){
        if($value[1] >= 3){
            $data .= ""
                . "<tr>
                        <td>{$index}</td>
                        <td><a>".getStudnetByID($value["attendance_std_id"])."</td>
                        <td>{$value[1]}</td>    
                        <td>".  getSchoolByID($value["attendance_std_id"])."</td>
                </tr>";
            $index++;
        }
    }
    return $data;
}

function getAbsentReportByDate($days){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT  `attendance_date` , COUNT(*) totalAttendance ,  `attendance_std_id` FROM  `attendance_tb` GROUP BY  `attendance_std_id` , DATE_FORMAT(`attendance_date`, '%Y%m')");
    while($value = mysql_fetch_array($result)){
        if($value[1] >= $days){
          //  echo "<script>alert('TRUE');</script>";
        $data .= ""
                . "<tr>
                        <td>{$index}</td>
                        <td><a href='".HostRoot."profile/".encode($value["attendance_std_id"])."'>".getStudnetByID($value["attendance_std_id"])."</a></td>
                        <td>{$value[1]}</td>    
                        <td>".  getSchoolByID($value["attendance_std_id"])."</td>
                </tr>";
            $index++;
        }
        
    }
    return $data;
}

function getFullReport($year){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT  `attendance_date` , COUNT( * ) ,  `attendance_std_id` FROM  `attendance_tb` WHERE DATE_FORMAT(  `attendance_date` ,  '%Y' ) =  '{$year}'");    
    while($value = mysql_fetch_array($result)){
        if($value[1] >= 3){
            $data .=getReports($value["attendance_std_id"]);
//                $data .= ""
//                . "<tr>
//                        <td>{$index}</td>
//                        <td>".getStudnetByID($value["attendance_std_id"])."</td>
//                        <td>{$value["attendance_date"]}</td>
////                </tr>";
//            $index++;
            }
        
        }
    return $data;
}

function getReport($id){
    $data = ""; $index = 1;
    $result = mysql_query("SELECT * FROM `attendance_tb` WHERE `attendance_std_id` = '$id'");
    while($value = mysql_fetch_array($result)){
        $data .= ""
              . "<tr>
//                        <td>{$index}</td>
//                        <td>".getStudnetByID($value["attendance_std_id"])."</td>
//                        <td>{$value["attendance_date"]}</td>
////                </tr>";
//            $index++;
            }  
    return $data;
}

function getStudnetByID($id){
    $_qry = "SELECT `ef_name` FROM `entry_form_tb` WHERE `ef_id` = '{$id}'";
    $result = mysql_query($_qry);
    $rw = mysql_fetch_array($result);
    return $rw["ef_name"];
}

function getSchoolByID($id){
    $_qry = "SELECT `ef_school_name` FROM `entry_form_tb` WHERE `ef_id` = '{$id}'";
    $result = mysql_query($_qry);
    $rw = mysql_fetch_array($result);
    return $rw["ef_school_name"];
}


function getDateRange($start, $end, $format = "m/d/Y") {
    //Create output variable
    $datesArray = array();
    //Calculate number of days in the range
    $total_days = round(abs(strtotime($end) - strtotime($start)) / 86400, 0) + 1;
    if ($total_days < 0) {
        return false;
    }
    //Populate array of weekdays and counts
    for ($day = 0; $day < $total_days; $day++) {
        $datesArray[] = date($format, strtotime("{$start} + {$day} days"));
    }
    //Return results array
    return $datesArray;
}
            
function getStudentAttendanceList($stdID){
    $data = "";
    $qry_1 = "SELECT * FROM `attendance_tb` WHERE `attendance_std_id` = '{$stdID}'";
    $result = mysql_query($qry_1);
    while($rw = mysql_fetch_array($result)){
        $data .= "<tr>"
                . "<td>".  convertFromSqlDate($rw["attendance_date"])."</td>"
                . "<td>Absent</td>"
                . "</tr>";
    }
    
    return $data;
}