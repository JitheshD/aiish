<?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "leobots_wandc_db";

//Set Directory Level
global $page_name, $_PID;

$url = explode("/", $_GET["parm"]);

$page_name = $url[0];

$_PID = getParameter($url);
/////////////////////////
//Set page prefix
define("PREFIX", "tm");

define("TO_MailID", "info@leobots.com"); //

//Set database table prefix
define("DB_PREFIX", "tm"); //optional

//Define url page masking value
define("404", "404");
define("user", "userinfo");
define("taluk", "taluk");
define("hobli", "hobli");
define("logout", "logout");
define("village", "village");
define("profile", "profile");
define("dashboard", "dashboard");
define("entry_form", "entry_form");
define("student_report", "students");
define("attendance", "attendance");
define("attendance_report", "attendance_report");
define("grama_panchayat", "grama_panchayat");



define("test", "test");
define("test2", "test2");


//////////////////////
setlocale(LC_MONETARY, 'en_IN');
//Set Location Time Zone
$timezone = "Asia/Calcutta";
if (function_exists('date_default_timezone_set')) {
    date_default_timezone_set($timezone);
}

//Get Page Name by URL reference
function getPageByReference($case) {
    return (defined($case)) ? constant($case) : "404";
}

function getParameter($url) {
    $level = $cid = $pid = $p1 = "";
    $size = sizeof($url);

    for ($i = $size; $i >= 0; $i--) {

        $level .= (empty($level) || $i == 0) ? "./" : "../";
        $p1 = $url[$i];
        if (is_numeric($p1) || is_numeric(decode($p1))) {
            $cid = $p1;
        } elseif (!empty($p1) && !is_numeric($p1)) {
            $pid[$p1] = $cid;
            $cid = "";
        }
    }
    define("HostRoot", $level);
    return $pid;
}
?>
