/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function(){
    //date_time("DateTime");
    setTimeout(function() {
        $('.alert').fadeOut('slow');
        $('#alert').fadeIn('slow');
    }, 5500);
});





$(".form-control, .select2-container").focusout(function() {
        $(this).css({"border": ""});
});

$(".required").focusout(function() {
    if ($.trim($(this).val()) === "") {
        $(this).focus();
        $(this).css({"border": "1px solid red"});
    } else
        $(this).css({"border": ""});
});

$(".required, .form-control, .select2-container").focus(function() {
        $(this).css({"border": "1px solid #1ff959"});
});

$("#PostSubmit").click(function (){
    
 });

//Validating Login Form
function validate() {
    var status = true;
    $("select").removeAttr("disabled");
    $("input").removeAttr("disabled");
    $(".disabled").removeAttr("disabled");
    
    $(".required").each(function() {
        if ($.trim($(this).val()) === "") {
            status = false;
            $(this).focus();
            $(this).css({"border": "1px solid red"});
        } else
            $(this).css({"border": ""});
    });
    $("select option:selected").each(function() {
        if ($.trim($(this).val()) === "") {
            status = false;
            $(this).focus();
            $(this).css({"border": "1px solid red"});
        } else
            $(this).css({"border": ""});
    });
    
    
    
//    $(".email").each(function(){
//        var re = /\S+@\S+\.\S+/;
//        if(!re.test($(this).val())){
//            status = false;
//            $(this).focus();
//            $(this).css({"border": "1px solid red"});
//        } else{ $(this).css({"border": ""});    }
//    });

//    if (status) {//if status = true the comfirm insertion informatrion
//        if (!confirm("Are you sure want to process this task..."))
//            status = false;
//    }

    return status;
}

function isNumber(evt) { // onkeypress="return isNumber(event)"
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function date_time(id)
{
    var date = new Date;
    var year = date.getFullYear();
    var month = date.getMonth();
    var months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'Jully', 'August', 'September', 'October', 'November', 'December');
    var d = date.getDate();
    var day = date.getDay();
    var days = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
    var h = date.getHours();
    if (h < 10)
    {
        h = "0" + h;
    }
    var m = date.getMinutes();
    if (m < 10)
    {
        m = "0" + m;
    }
    var s = date.getSeconds();
    if (s < 10)
    {
        s = "0" + s;
    }
    var result = '' + days[day] + ' ' + months[month] + ' ' + d + ' ' + year + ', ' + h + ':' + m + ':' + s;
    window.document.getElementById(id).innerHTML = result;
    setTimeout('date_time("' + id + '");', '1000');
    return true;
}

function GetTime(){
    var now = new Date(); 
    var hour = now.getHours();
    var minute = now.getMinutes(); 
    var DateTime = "";
    
    if (hour < 10){ hour = "0" + hour;  }
    if (minute < 10){   minute = "0" + minute;  }
    
//    if(hour > 11){
//        DateTime = (hour-12) + ":" + minute + " PM";
//    } else {
//        DateTime = (hour) + ":" + minute + " AM";
//    }
    DateTime = (hour) + ":" + minute;
    return DateTime;
}

function reverseDate(s){
    return s.split("-").reverse().join("-");
}