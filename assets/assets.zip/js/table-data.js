
$('.table-info').dataTable({
    "aaSorting" : [[1, 'desc']],
    "aLengthMenu" : [[5, 10, 15, 20, -1], [5, 10, 15, 20, "All"]],
    // set the initial value
    "iDisplayLength" : 10
});
