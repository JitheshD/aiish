<?php
include_once '../lib/maincore.php';
$taluk = (isset($_POST["taluk"])) ? strip_tags($_POST["taluk"]) : "";
$gp = (isset($_POST["gp"])) ? strip_tags($_POST["gp"]) : "";

$tmp_data = getGPVillageSelectList($taluk, "", $gp);
echo $tmp_data;
?>