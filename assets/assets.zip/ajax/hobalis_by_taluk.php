<?php
include_once '../lib/maincore.php';
$pid = (isset($_POST["pid"])) ? strip_tags($_POST["pid"]) : "";

$tmp_data = getTalukHobaliSelectList($pid);
echo "test". $pid;
?>