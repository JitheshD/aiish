<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once '../lib/maincore.php';


$pid = strip_tags($_POST["pid"]);
$date = convertToSqlDate(strip_tags($_POST["aDate"]));
$attendance = strip_tags($_POST["attendance"]);


$qry_1 = "SELECT * FROM `attendance_tb` WHERE DATE(`attendance_date`) = DATE('{$date}') AND `attendance_std_id` = '{$pid}'";
$result = mysql_query($qry_1);
if(mysql_num_rows($result) >= 1 && intval($attendance) == 1){
    $qry_2 = "DELETE FROM `attendance_tb` WHERE DATE(`attendance_date`) = DATE('{$date}') AND `attendance_std_id` = '{$pid}'";
    mysql_query($qry_2);
}else{
    if(intval($attendance)==2){ 
        $qry_2 = "INSERT INTO `attendance_tb` (`attendance_date`,`attendance_std_id`,`attendance_status`) VALUES ('{$date}', '{$pid}', '2')";
        mysql_query($qry_2);
    }
}


if(mysql_errno()){
    echo "error";
}else{
    echo "done";
}