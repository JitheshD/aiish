            </div>
            <!-- start: FOOTER -->
            <footer>
                <div class="footer-inner">
                    <div class="pull-left">
                        &copy; <span class="current-year"></span> <span class="text-bold text-uppercase">Zill Panchayath, Udupi</span>. <span>All rights reserved</span>
                        
                    </div>
                    <div class="pull-right">
                        <a href="http://www.leobots.com"><small>Developed by Leobots Technologies</small></a>&nbsp;&nbsp;<span class="go-top"><i class="ti-angle-up"></i></span>
                    </div>
                </div>
            </footer>
            <!-- end: FOOTER -->
            
        </div>
        <!-- start: MAIN JAVASCRIPTS -->
        <!--extra-->
        
        <script src="<?php echo HostRoot; ?>vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/modernizr/modernizr.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/jquery-cookie/jquery.cookie.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/switchery/switchery.min.js"></script>
        <!-- end: MAIN JAVASCRIPTS -->
        <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
        <script src="<?php echo HostRoot; ?>vendor/Chart.js/Chart.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/jquery.sparkline/jquery.sparkline.min.js"></script>
        <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
        <!-- start: CLIP-TWO JAVASCRIPTS -->
        <script src="<?php echo HostRoot; ?>assets/js/main.js"></script>
        <script src="<?php echo HostRoot; ?>assets/js/master.admin.js"></script>
        <!-- start: JavaScript Event Handlers for this page -->
        <script src="<?php echo HostRoot; ?>vendor/selectFx/classie.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/selectFx/selectFx.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/select2/select2.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/DataTables/jquery.dataTables.min.js"></script>
        <script src="<?php echo HostRoot; ?>assets/js/table-data.js"></script>
        <script src="<?php echo HostRoot; ?>assets/js/index.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script>
            jQuery(document).ready(function () {
                Main.init();
                Index.init();
            });
        </script>
        <!-- end: JavaScript Event Handlers for this page -->
        <!-- end: CLIP-TWO JAVASCRIPTS -->
    </body>
</html>
