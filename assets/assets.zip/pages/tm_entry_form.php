<?php
$formData = ToDoEntryForm($_POST, $_PID, $_FILES);
if ($_POST["taluk"]) {
    $_SESSION["loc"]["taluk"] = $_POST["taluk"];
    $_SESSION["loc"]["hobali"] = $_POST["hobali"];
    $_SESSION["loc"]["gp"] = $_POST["panchayath"];
    $_SESSION["loc"]["village"] = $_POST["village"];
}
if(!empty($formData)){
    $_SESSION["loc"]["taluk"] = $formData["ef_taluk"];
    $_SESSION["loc"]["hobali"] = $formData["ef_hobali"];
    $_SESSION["loc"]["gp"] = $formData["ef_gramapanchayath"];
    $_SESSION["loc"]["village"] = $formData["ef_village"];
}
//unset($_SESSION["loc"]);
?>

<link href="<?php echo HostRoot; ?>vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
<link href="<?php echo HostRoot; ?>vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
<link href="<?php echo HostRoot; ?>vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
<style>
    .form-group{margin-bottom: 5px !important; }
</style>

<div class="main-content" >
    <div class="wrap-content container" id="container">
        <!-- start: PAGE TITLE -->
        <section id="page-title">
            <div class="row">
                <div class="col-sm-8">
                    <h1 class="mainTitle">ಶೈಕ್ಷಣಿಕ ವಿವರ</h1>
                </div>
                <ol class="breadcrumb">
                    <li>
                        <span>Dashboard</span>
                    </li>
                    <li class="active">
                        <span>Entry Form</span>
                    </li>
                </ol>
            </div>
        </section>
        <?php echo getSessionMsg(); ?>
        <!-- end: PAGE TITLE -->
        <!-- start: WIZARD DEMO -->
        <div class="container-fluid container-fullw bg-white">
            <div class="row">              
                <form action="<?php echo HostRoot.$page_name; ?>" method="post" enctype="multipart/form-data" role="form">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>
                                Taluk
                            </label>
                            <select class="form-control" name="taluk" id="taluk"> <?php echo getTalukSelectList($_SESSION["loc"]["taluk"]); ?> </select>
                        </div>
                    </div>
                    <!--                        <div class="col-md-3">
                                                <div class="form-group">
                                                    <label>
                                                        Hobali
                                                    </label>
                                                    <select class="form-control" name="hobali" id="hobali"> <?php echo (isset($_SESSION["loc"]["hobali"])) ? getTalukHobaliSelectList($_SESSION["loc"]["taluk"], $_SESSION["loc"]["hobali"]) : "<option value=''>Select Hobali</option>"; ?> </select>
                                                </div>
                                            </div>-->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>
                                Panchayath
                            </label>
                            <select class="form-control" name="panchayath" id="panchayath">  <?php echo (isset($_SESSION["loc"]["gp"])) ? getHobaliGPSelectList($_SESSION["loc"]["taluk"], $_SESSION["loc"]["hobali"], $_SESSION["loc"]["gp"]) : "<option value=''>Select Panchayath</option>"; ?> </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>
                                Village
                            </label>
                            <select class="form-control" name="village" id="village"> <?php echo (isset($_SESSION["loc"]["village"])) ? getGPVillageSelectList($_SESSION["loc"]["taluk"], $_SESSION["loc"]["hobali"], $_SESSION["loc"]["gp"], $_SESSION["loc"]["village"]) : "<option value=''>Select Village</option>"; ?> </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group"  style="margin-top: 22px">
                            <button type="submit" class="btn btn-primary" name="SubmitLocation"> <i class="fa fa-file"></i> Go </button>
                        </div>
                    </div>
                </form>

                <?php
                if (isset($_SESSION["loc"])) {
                    ?>
                    <div class="col-md-12">

                        <!-- start: WIZARD FORM -->
                        <form action="<?php echo HostRoot.$page_name; ?>" method="post" enctype="multipart/form-data"  role="form" method="POST" class="smart-wizard" id="form" >
                        <!--<form  role="form" method="POST" class="smart-wizard" id="form" enctype="multipart/formdata">-->
                            <div id="wizard" class="swMain">
                                <!-- start: WIZARD SEPS -->
                                <ul>
                                    <li>
                                        <a href="#step-1">
                                            <div class="stepNumber">
                                                1
                                            </div>
                                            <span class="stepDesc"><small> ಶೈಕ್ಷಣಿಕ ವಿವರ 1</small></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#step-2">
                                            <div class="stepNumber">
                                                2
                                            </div>
                                            <span class="stepDesc"> <small> ಶೈಕ್ಷಣಿಕ ವಿವರ 2 </small></span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#step-3">
                                            <div class="stepNumber">
                                                3
                                            </div>
                                            <span class="stepDesc"> <small>ಶೈಕ್ಷಣಿಕ ವಿವರ 3 </small> </span>
                                        </a>
                                    </li>

                                </ul>
                                <!-- end: WIZARD SEPS -->
                                <!-- start: WIZARD STEP 1 -->
                                <div id="step-1">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <fieldset>
                                                <legend>
                                                    ಶೈಕ್ಷಣಿಕ ವಿವರ ೧
                                                </legend>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>
                                                                ಹೆಸರು <span class="symbol required"></span>
                                                            </label>
                                                            <!--<input type="text" name="age" placeholder="" class="form-control" />-->
                                                            <input type="text" placeholder="ಹೆಸರು" class="form-control" name="firstName" value="<?php echo $formData["ef_name"]; ?>"/>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>
                                                                ಲಿಂಗ <span class="symbol required"></span>
                                                            </label>
                                                            <div class="clip-radio radio-primary">
                                                                <input type="radio" id="wz-female" name="gender" value="female" <?php echo (empty($formData["ef_sex"]) || $formData["ef_sex"] == "female")? "checked" : ""; ?> >
                                                                <label for="wz-female">
                                                                    ಸ್ತ್ರೀ
                                                                </label>
                                                                <input type="radio" id="wz-male" name="gender" value="male" <?php echo ($formData["ef_sex"] == "male")? "checked" : ""; ?>>
                                                                <label for="wz-male">
                                                                    ಪುರುಷ
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>
                                                                ಭಾವಚಿತ್ರ 
                                                            </label>
                                                            <input type="file" name="std_photo[]"/>
                                                            <input type="hidden" name="std_photo1" value="<?php echo $formData["ef_photo"] ?>">   
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>
                                                                ವಯಸ್ಸು <span class="symbol required"></span>
                                                            </label>
                                                            <input type="text" name="age" class="form-control" placeholder="ವಯಸ್ಸು" value="<?php echo $formData["ef_age"]; ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>
                                                                ಜನ್ಮದಿನಾಂಕ <span class="symbol required"></span>
                                                            </label>
                                                            <!--<input type="text" name="dob" placeholder="" class="form-control" />-->
                                                            <p class="input-group input-append datepicker date">
                                                                <input type="text" name="dob" class="form-control" value="<?php echo convertFromSqlDate($formData["ef_dob"]); ?>"/>
                                                                <span class="input-group-btn">
                                                                    <button type="button" class="btn btn-default">
                                                                        <i class="glyphicon glyphicon-calendar"></i>
                                                                    </button> </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>
                                                                ಜಾತಿ <span class="symbol required"></span>
                                                            </label>
                                                            <input type="text" name="religion" placeholder="" class="form-control" value="<?php echo $formData["ef_cast"]; ?>" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ತಂದೆಯ ಹೆಸರು <span class="symbol"></span>
                                                            </label>
                                                            <input type="text" name="father_name" placeholder="" class="form-control" value="<?php echo $formData["ef_fathername"]; ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ತಂದೆಯ ಉದ್ಯೋಗ <span class="symbol"></span>
                                                            </label>
                                                            <input type="text" name="father_occupation" placeholder="" class="form-control" value="<?php echo $formData["ef_fatheroccupation"]; ?>"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ತಾಯಿಯ ಹೆಸರು <span class="symbol"></span>
                                                            </label>
                                                            <input type="text" name="mother_name" placeholder="" class="form-control" value="<?php echo $formData["ef_mothername"]; ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ತಾಯಿಯ ಉದ್ಯೋಗ <span class="symbol"></span>
                                                            </label>
                                                            <input type="text" name="mother_occupation" placeholder="" class="form-control" value="<?php echo $formData["ef_motheroccupation"]; ?>"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ದೂರವಾಣಿ ಸಂಖ್ಯೆ <span class="symbol"></span>
                                                            </label>
                                                            <input type="text" name="phone_no" placeholder="" class="form-control" value="<?php echo $formData["ef_contact"]; ?>"/>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ಪ್ರಸ್ತುತ ವಿಳಾಸ <span class="symbol"></span>
                                                            </label>
                                                            <textarea cols="3" class="form-control" name="address"><?php echo $formData["ef_present_address"]; ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ಖಾಯಂ ವಿಳಾಸ <span class="symbol"></span>
                                                            </label>
                                                            <textarea cols="3" class="form-control" name="permanent_address"><?php echo $formData["ef_permanent_address"]; ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>



                                            </fieldset>

                                            <div class="form-group">
                                                <button class="btn btn-primary btn-o next-step btn-wide pull-right">
                                                    Next <i class="fa fa-arrow-circle-right"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- end: WIZARD STEP 1 -->
                                <!-- start: WIZARD STEP 2 -->
                                <div id="step-2">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <fieldset>
                                                <legend>
                                                    ಶೈಕ್ಷಣಿಕ ವಿವರ ೨
                                                </legend>


                                                <div class="row hidden">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>
                                                                ಶಾಲೆಗೆ  ದಾಖಲಾಗಿದೆ 
                                                            </label>
                                                            <div class="clip-radio radio-primary">
                                                                <input type="radio" class="wz-joined" id="wz-joined-yes" name="joined" >
                                                                <label for="wz-joined-yes">
                                                                    ಹೌದು
                                                                </label>
                                                                <input type="radio" class="wz-joined" id="wz-joined-no" name="joined">
                                                                <label for="wz-joined-no">
                                                                    ಇಲ್ಲ
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="" id="continue">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಶಾಲೆಯ ಹೆಸರು <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="ಶಾಲೆಯ ಹೆಸರು" class="form-control" name="school_name" value="<?php echo $formData["ef_school_name"]; ?>"/>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಪ್ರಸ್ತುತ ಕಲಿಯುತ್ತಿರುವ ತರಗತಿ <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="class" value="<?php echo $formData["ef_school_address"]; ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ತರಗತಿ ಶಿಕ್ಷಕರ ಹೆಸರು <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="teacher_name" value="<?php echo $formData["ef_teacher_name"]; ?>"/>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ತರಗತಿ ಶಿಕ್ಷಕರ ದೂರವಾಣಿ ಸಂಖ್ಯೆ <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="teacher_phone_no" value="<?php echo $formData["ef_teacher_contact"]; ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಮುಖ್ಯೋಪಾದ್ಯಾಯರ ಹೆಸರು <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="headmaster_name" value="<?php echo $formData["ef_headmaster_name"]; ?>"/>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಮುಖ್ಯೋಪಾದ್ಯಾಯರ ದೂರವಾಣಿ ಸಂಖ್ಯೆ <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="headmaster_phone_no" value="<?php echo $formData["ef_headmaster_contact"]; ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಶಾಲೆಯ ವಿಳಾಸ <span class="symbol required"></span>
                                                                </label>
                                                                <textarea placeholder="ಶಾಲೆಯ ವಿಳಾಸ " rows="3" name="school_address" class="form-control"><?php echo $formData["ef_school_address"]; ?></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಅಂಗನವಾಡಿ ಕೇಂದ್ರ <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="anganavadi_center" value="<?php echo $formData["ef_anganavadi_center"]; ?>">
                                                                <label class="control-label">
                                                                    ಅಂಗನವಾಡಿ ಕಾರ್ಯಕರ್ತೆಯ ಹೆಸರು <span class="symbol required"></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="anganavadi_teacher" value="<?php echo $formData["ef_anganavadi_teacher"]; ?>">
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </fieldset>
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-o back-step btn-wide pull-left">
                                                    <i class="fa fa-circle-arrow-left"></i> Back
                                                </button>
                                                <button class="btn btn-primary btn-o next-step btn-wide pull-right">
                                                    Next <i class="fa fa-arrow-circle-right"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="step-3">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <fieldset>
                                                <legend>
                                                    ಶೈಕ್ಷಣಿಕ ವಿವರ ೩
                                                </legend>

                                                <div class="row" id="discontinue">
                                                    <div class="col-md-4" id="quitted">
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಶಾಲೆ ಬಿಟ್ಟಿದೆ 
                                                            </label>
                                                            <div class="clip-radio radio-primary">
                                                                <input type="radio" class="quitted" id="wz-quitted_yes" name="quitted_school" value="yes" <?php echo (empty($formData["ef_quit_school"]) || $formData["ef_quit_school"] == "yes")? "checked" : ""; ?>>
                                                                <label for="wz-quitted_yes">
                                                                    ಹೌದು
                                                                </label>
                                                                <input type="radio" class="quitted" id="wz-quitted_no" name="quitted_school" value="no" <?php echo ($formData["ef_quit_school"] == "no")? "checked" : ""; ?>>
                                                                <label for="wz-quitted_no">
                                                                    ಇಲ್ಲ
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class='quitted_yes <?php echo (!empty($formData["ef_quit_school"]) || $formData["ef_quit_school"] == "no")? "hidden" : ""; ?>' >
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಶಾಲೆ ಬಿಟ್ಟಾಗ ತರಗತಿ <span class=""></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="quitting_class" value="<?php echo $formData["ef_quit_class"]; ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                     ಶಾಲೆ ಬಿಟ್ಟಾಗ ಶಾಲೆಯ ಹೆಸರು <span class=""></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="quitting_school_name" value="<?php echo $formData["ef_quit_school_name"]; ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                <div class="row quitted_yes <?php echo (!empty($formData["ef_quit_school"]) || $formData["ef_quit_school"] == "no")? "hidden" : ""; ?>">
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಎಷ್ಟು ದಿನ/ತಿಂಗಳು <span class=""></span>
                                                                </label>
                                                                <input type="text" placeholder="" class="form-control" name="days" value="<?php echo $formData["ef_numberofdays"]; ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="form-group">
                                                                <label class="control-label">
                                                                    ಶಾಲೆ ಬಿಟ್ಟ ದಿನಾಂಕ <span class=""></span>
                                                                </label>
                                                                <!--<input type="text" placeholder="" class="form-control" name="quitting_date" value="<?php echo $formData["ef_quitting_date"]; ?>">-->
                                                                <p class="input-group input-append datepicker date">
                                                                <input type="text" name="quitting_date" class="form-control" value="<?php echo convertFromSqlDate($formData["ef_quitting_date"]); ?>"/>
                                                                <span class="input-group-btn">
                                                                    <button type="button" class="btn btn-default">
                                                                        <i class="glyphicon glyphicon-calendar"></i>
                                                                    </button> </span>
                                                            </p>
                                                            </div>
                                                        </div>
                                                    <div class="col-md-3">
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಪುನಃ ಶಾಲೆಗೆ ಸೇರ್ಪಡೆಯಾಗಿದೆ <span class=""></span>
                                                            </label>
                                                            <div class="clip-radio radio-primary">
                                                                <input type="radio" class="readmition" id="wz-readmition_yes" name="readmition" value="yes" <?php echo ($formData["ef_readmition"] == "yes")? "checked" : ""; ?>>
                                                                <label for="wz-readmition_yes">
                                                                    ಹೌದು
                                                                </label>
                                                                <input type="radio" class="readmition" id="wz-readmition_no" name="readmition" value="no" <?php echo (empty($formData["ef_readmition"]) || $formData["ef_readmition"] == "no")? "checked" : ""; ?>>
                                                                <label for="wz-readmition_no">
                                                                    ಇಲ್ಲ
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="col-md-3 readmition-yes  <?php echo (empty($formData["ef_readmition"]) || $formData["ef_readmition"] == "no")? "hidden" : ""; ?>" >
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಸೇರ್ಪಡೆಯಾದಲ್ಲಿ ಶಾಲೆಯ ಹೆಸರು <span class=""></span>
                                                            </label>
                                                            <input type="text" placeholder="" class="form-control" name="readmition_school_name" value="<?php echo $formData["ef_readmition_school_name"]; ?>">
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                <div class="row">

                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಎಲ್ಲಿಂದ ವಲಸೆ  <span class=""></span>
                                                            </label>
                                                            <input type="text" placeholder="" class="form-control" name="immigration" value="<?php echo $formData["ef_immigrationfrom"]; ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಎಷ್ಟು ದಿನ ಇಲ್ಲಿ ಇರುತ್ತಾರೆ <span class=""></span>
                                                            </label>
                                                            <input type="text" placeholder="" class="form-control" name="staying" value="<?php echo $formData["ef_staying_days"]; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಎಲ್ಲಿಗೆ ಹೋಗುತ್ತಾರೆ <span class=""></span>
                                                            </label>
                                                            <input type="text" placeholder="" class="form-control" name="going" value="<?php echo $formData["ef_gotower"]; ?>"/>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                ಕೈಗೊಳ್ಳಬೇಕಾದ ಕ್ರಮಗಳು  <span class="symbol required"></span>
                                                            </label>
                                                            <textarea cols="3" name="stepstobetaken" class="form-control"><?php echo $formData["ef_stepstobetaken"]; ?></textarea>
                                                        </div>
                                                    </div>

                                                </div>

                                            </fieldset>
                                            <div class="form-group">
                                                <button class="btn btn-primary btn-o back-step btn-wide pull-left">
                                                    <i class="fa fa-circle-arrow-left"></i> Back
                                                </button>
                                                <input type="hidden" name="entryform_id" value="<?php echo $formData["ef_id"]; ?>">
                                                <button type="submit" name="submitentry_form" class="btn btn-primary  btn-wide pull-right">
                                                    Submit Info <i class="fa fa-save"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- start: WIZARD STEP 4 -->
                                <div id="step-4">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="text-center">
                                                <h1 class=" ti-check block text-primary"></h1>
                                                <a class="btn btn-primary btn-o go-first" href="javascript:void(0)">
                                                    Back to first step
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end: WIZARD STEP 4 -->
                        </form>
                    </div>
                <?php } ?>
                <!-- end: WIZARD FORM -->
            </div>
        </div>
    </div>
</div>


<script src="<?php echo HostRoot ?>vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo HostRoot ?>vendor/jquery-smart-wizard/jquery.smartWizard.js"></script>
<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->

<!-- start: JavaScript Event Handlers for this page -->
<script src="<?php echo HostRoot ?>assets/js/form-wizard.js"></script>
<script src="<?php echo HostRoot; ?>vendor/maskedinput/jquery.maskedinput.min.js"></script>
<script src="<?php echo HostRoot; ?>vendor/autosize/autosize.min.js"></script>
<script src="<?php echo HostRoot; ?>vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?php echo HostRoot; ?>vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>

<script src="<?php echo HostRoot; ?>assets/js/form-elements.js"></script>
<script>
    jQuery(document).ready(function () {
        FormWizard.init();
        FormElements.init();
    });
</script> 

<script>
    jQuery(document).ready(function () {
        /*
//         $('.wz-joined').change(function() {
//         if($('#wz-joined-yes').is(':checked')) { $("#quitted").removeClass("hidden"); }
//         if($('#wz-joined-no').is(':checked')) { $("#quitted").addClass("hidden"); }
//         });*/
         $('input.quitted').change(function () {
            if($(this).val() === "yes") { $(".quitted_yes").removeClass("hidden"); }
             if($(this).val() === "no") {  $(".quitted_yes").addClass("hidden"); }
         });
         $('input.readmition').change(function () {
            if($(this).val() === "yes") { $(".readmition-yes").removeClass("hidden"); }
             if($(this).val() === "no") {  $(".readmition-yes").addClass("hidden"); }
         });
        
    });


    $("#taluk").change(function () {
        var id = $(this).val();
        var action = BASEDIR + "assets/ajax/grama_panchayath_list.php";
        $.post(action, {
            pid: id
        },
        function (data) {
            $("#panchayath").empty().append(data.trim());
        });
    });

    $("#panchayath").change(function () {
        var tq = $("#taluk option:selected").val();
        var id = $(this).val();
        var action = BASEDIR + "assets/ajax/village_list.php";
        $.post(action, {
            taluk: tq,
            gp: id
        },
        function (data) {
            $("#village").empty().append(data.trim());
        });
    });
</script>
