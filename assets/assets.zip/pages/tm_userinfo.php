<?php
$formData = ToDoUserForm($_POST, $_PID, $_FILES);
$count = getUserCount();
?>

<div class="main-content" >
    <div class="wrap-content container" id="container">
        <!-- start: DASHBOARD TITLE -->
        <section id="page-title" class="padding-top-15 padding-bottom-15">
            <div class="row">
                <div class="col-sm-7">
                    <h1 class="mainTitle"><i class="fa fa-users"></i> User Info</h1>
                    <!--<span class="mainDescription">overview &amp; details </span>-->
                </div>
                <div class="col-sm-5">
                    <!-- start: MINI STATS WITH SPARKLINE -->
                    <ul class="mini-stats pull-right">
                        <li>
                            <div class="values">
                                <strong class="text-dark"><?php echo $count["TotalUser"];?></strong>
                                <p class="text-small no-margin">
                                    Total User
                                </p>
                            </div>
                        </li>
                        <li>
                            <div class="values text-info">
                                <strong class="text-dark"><?php echo $count["ActiveUser"];?></strong>
                                <p class="text-small no-margin">
                                    Active
                                </p>
                            </div>
                        </li>
                        <li>
                            <div class="values text-danger">
                                <strong class="text-dark"><?php echo $count["InactiveUser"];?></strong>
                                <p class="text-small no-margin">
                                    Inactive
                                </p>
                            </div>
                        </li>
                    </ul>
                    <!-- end: MINI STATS WITH SPARKLINE -->
                </div>
            </div>
        </section>
        <!-- end: DASHBOARD TITLE -->

        <!-- start: DYNAMIC TABLE -->
        <div class="container-fluid container-fullw bg-white">
            <div class="row">
                <div class="col-md-12">
<?php echo getSessionMsg(); ?>
                    <div class="row">
                        <div class="col-md-12 space20">
                            <button class="btn btn-green add-row" data-toggle="modal" data-target=".bs-example-modal-left" onclick="$('input').val('')">
                                Add New <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-info">
                            <thead>
                                <tr>
                                    <th>Full Name</th>
                                    <th>Username</th>
                                    <th>User Level</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
<?php echo getUserList(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>

<?php 
    if(!empty($_PID["user"])){
        echo "<script>
                jQuery('document').ready(function (){
                    $('.bs-example-modal-left').modal('show');
                });
            </script>";
    }

?>

<div class="modal fade modal-aside horizontal left bs-example-modal-left"  tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">User Profile Detail</h4>
            </div>
            <div class="modal-body">
                <form  role="form" action="<?php echo HostRoot.$page_name; ?>" method="POST" onsubmit="return validate()">
                        <div class="box-body">
                            
                            <div class="form-group">
                                <label>Full Name</label>
                                <input type="text" class="form-control required" name="full_name" placeholder="User Full Name"  value="<?php echo $formData["user_full_name"]; ?>" />
                            </div>
                            <div class="form-group">
                                <label>User Name</label>
                                <input type="text" class="form-control required" name="username" placeholder="User Name : " value="<?php echo $formData["user_name"]; ?>" />
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control required" name="password" placeholder="Password"  value="<?php echo (!empty($formData["user_password"])) ? decode($formData["user_password"]) : ""; ?>"/>
                            </div>
                            
                            <div class="form-group" style="<?php echo (USERAUTH != 1) ? "display:none;" : "";?>">
                                <label>Authentication</label>
                                <select class="form-control required" name="user_level" > <?php echo getAuthSelectList($formData["user_level"]); ?></select>
                            </div>

                        </div><!-- /.box-body -->
                        <hr />
                        <div class="box-footer">
                            <div class="pull-right">
                                <input type="hidden" name="user_id" value="<?php echo $formData["user_id"]; ?>">
                                <button type="submit" name="SubmitUser" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                            </div>
                            <button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Discard</button>
                        </div><!-- /.box-footer -->
                    </form>
            </div>
            
        </div>
    </div>
</div>