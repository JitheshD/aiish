<?php
$status = FALSE;
if (isset($_POST["btnAttend"])) {
    $status = TRUE;
//    $date_from = (isset($_POST["datefrom"])) ? $_POST["datefrom"] : "";
//    $date_to = (isset($_POST["dateto"])) ? (isset($_POST["dateto"])) : "";
    $date_from = $_POST["datefrom"];
    $date_to = $_POST["dateto"];
    $school = $_POST["schoolname"];
    $start = $date_from;
    $end = $date_to;
}

?>


<div class="container-fluid container-fullw bg-white">
    <div class="main-content">
        <div class="row">
            <div class="col-md-12">
                <form role="form" action="attendance" method="post">
                    <fieldset>
                        <legend>
                           ಹಾಜರಾತಿ ನೀಡಿ 
                        </legend>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>
                                        ರಿಂದ <span class="symbol required"></span>
                                    </label>
                                    <p class="input-group input-append datepicker date">
                                        <input type="text" name="datefrom" class="form-control"/>
                                        <span class="input-group-btn">
                                            <button type="button" class="btn btn-default">
                                                <i class="glyphicon glyphicon-calendar"></i>
                                            </button> 
                                        </span>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>
                                        ರಿಗೆ <span class="symbol required"></span>
                                    </label>
                                <!--<input type="text" name="dob" placeholder="" class="form-control" />-->
                                    <p class="input-group input-append datepicker date">
                                        <input type="text" name="dateto" class="form-control"/>
                                        <span class="input-group-btn">
                                            <button type="button" class="btn btn-default">
                                                <i class="glyphicon glyphicon-calendar"></i>
                                            </button> 
                                        </span>
                                    </p>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>
                                        ಶಾಲೆಯ ಆಯ್ಕೆ
                                    </label>
                                    <div  id="container">
                                        <select class="form-control" name="schoolname[]" id="lstSchools" multiple="multiple">
                                            <?php echo getSchoolNameList(); ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <br>
                                    <div class="">
                                        <button class="btn btn-primary" name="btnAttend" type="submit">GO</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>

<?php if ($status != FALSE) { ?>

    <?php
    echo getSchoolName($school);
//         foreach ($school as $names)
//    {
//            $school_name = ($names) ? ($names) : "";
//            echo "$school_name";
////            echo getStudentList($school_name);
//    }
//    
    ?>


            <div class="table-responsive">
            <?php if ($start < $end) { ?>
                <?php $dateRange = getDateRange($start, $end); ?>
                    <table class="table table-striped table-hover table-info">
                        <thead>
                            <tr>
                                <th>ವಿದ್ಯಾರ್ಥಿಯ ಹೆಸರು</th>
                                    <?php foreach ($dateRange as $value) { ?>
                                    <th><?php echo date("d/m/Y", strtotime($value)); ?></th>
                                 <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                                <?php
                                foreach ($school as $names) {
                                    $school_name = ($names) ? ($names) : "";
                                    echo getStudentList($school_name, $dateRange); //print_r($names) 
                                }

//                        $i = 0;
//                        foreach ($dateRange as $value){ 
                                ?>
        <!--                        <td>
                                    <select name="attend_status">
                            <?php // echo getAttendanceSelectList(); ?>
                                    </select>    
                                </td>-->

                            <?php //   }  ; ?>

                        </tbody>
                    </table>
    <?php
    } else {
        echo "<script>alert('Enter Valid Date')</script>";
    }
    ?>

            </div>
            <?php } ?>
    </div>
</div>

<link href="<?php echo HostRoot; ?>vendor/bootstrap/css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />
<script src="<?php echo HostRoot; ?>vendor/bootstrap/js/bootstrap-multiselect.js" type="text/javascript"></script>

<script type="text/javascript">
    $(function () {
        $('#lstSchools').multiselect({
            includeSelectAllOption: true
        });

    });
</script>

<!--datepicker-->
<script src="<?php echo HostRoot; ?>vendor/maskedinput/jquery.maskedinput.min.js"></script>
<script src="<?php echo HostRoot; ?>vendor/autosize/autosize.min.js"></script>
<script src="<?php echo HostRoot; ?>vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?php echo HostRoot; ?>vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>

<script src="<?php echo HostRoot; ?>assets/js/form-elements.js"></script>
<script>
jQuery(document).ready(function () {
    FormElements.init();
    dateFormat: 'dd-mm-yyyy'
});


function setAttendance(id, dateRange ){
    var val = $("#std_"+id+dateRange+" option:selected").val();
    
    $.ajax({
        type: "POST",
        url: BASEDIR+"./assets/ajax/todo_attendance_entry.php",
        data: {pid: id, aDate: dateRange, attendance: val},
        cache: false,
        success: function (result) {
            //  alert(result);
        }
    });
}

</script> 









<!--if want-->
<!--    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="block">
                                Gender
                            </label>
                            <div class="clip-radio radio-primary">
                                <input type="radio" id="female" name="gender" value="female">
                                <label for="female">
                                    Female
                                </label>
                                <input type="radio" id="male" name="gender" value="male" checked="checked">
                                <label for="male">
                                    Male
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>
                                Choose your country or region
                            </label>
                            <select name="country" class="form-control">
                                <option value="">&nbsp;</option>
                                <option value="AL">Alabama</option>
                                <option value="AK">Alaska</option>
                                <option value="AZ">Arizona</option>
                            </select>
                        </div>
                    </div>
                </div>-->











