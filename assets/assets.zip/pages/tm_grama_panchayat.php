
<div class="main-content" >
    <div class="wrap-content container" id="container">
        <!-- start: DASHBOARD TITLE -->
        <section id="page-title" class="padding-top-15 padding-bottom-15">
            <div class="row">
                <div class="col-sm-7">
                    <h1 class="mainTitle"><i class="fa fa-map-marker"></i> Grama Panchaayat List</h1>
                    <!--<span class="mainDescription">overview &amp; details </span>-->
                </div>
                <div class="col-sm-5">
                    <!-- start: MINI STATS WITH SPARKLINE -->
                    <ul class="mini-stats pull-right">
                        <li>
                            <div class="values">
                                <strong class="text-dark"><?php// echo $count["TotalUser"];?></strong>
                                <p class="text-small no-margin">
                                    Total Panchayat
                                </p>
                            </div>
                        </li>
                        <li>
                            <div class="values text-info">
                                <strong class="text-dark"><?php //echo $count["ActiveUser"];?></strong>
                                <p class="text-small no-margin">
                                    Active
                                </p>
                            </div>
                        </li>
                        <li>
                            <div class="values text-danger">
                                <strong class="text-dark"><?php// echo $count["InactiveUser"];?></strong>
                                <p class="text-small no-margin">
                                    Inactive
                                </p>
                            </div>
                        </li>
                    </ul>
                    <!-- end: MINI STATS WITH SPARKLINE -->
                </div>
            </div>
        </section>
        <!-- end: DASHBOARD TITLE -->

        <!-- start: DYNAMIC TABLE -->
        <div class="container-fluid container-fullw bg-white">
            <div class="row">
                <div class="col-md-12">
                    <?php echo getSessionMsg(); ?>
<!--                    <div class="row">
                        <div class="col-md-12 space20">
                            <button class="btn btn-green add-row" data-toggle="modal" data-target=".bs-example-modal-left" onclick="$('input').val('')">
                                Add New <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>-->
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-info">
                            <thead>
                                <tr>
                                    <th>Panchayat Name</th>
                                    <th>Hobli Name</th>
                                    <th>Taluk Name</th>
                                    <th>status</th>
                                    <!--<th>action</th>-->
                                   
                                </tr>
                            </thead>
                            <tbody>
                                <?php echo getPachayatList(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>

