
<div class="main-content" >
    <div class="wrap-content container" id="container">
        <!-- start: PAGE TITLE -->
        <section id="page-title">
            <div class="row">
                <div class="col-sm-8">
                    <h1 class="mainTitle">ವಿದ್ಯಾರ್ಥಿಗಳ ಮಾಹಿತಿ</h1>
                </div>
                <ol class="breadcrumb">
                    <li>
                        <span>Dashboard</span>
                    </li>
                    <li class="active">
                        <span>Student Information</span>
                    </li>
                </ol>
            </div>
        </section>
        <?php echo getSessionMsg(); ?>
        <!-- start: FEATURED BOX LINKS -->
        <div class="container-fluid container-fullw bg-white clearfix">

            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12 space20">
                            <a href="<?php echo HostRoot."entry_form"; ?>" class="btn btn-green add-row">
                                Add New <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-info">
                            <thead>
                                <tr>
                                    <th>Ref No.</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>Age</th>
                                    <th>DOB</th>
                                    <th>Cast</th>
                                    <th>Father Name</th>
                                    <th>Contact No.</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php echo getStudentProfileList(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        

    </div>
</div>