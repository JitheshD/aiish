<?php
    session_destroy();
    redirect(HostRoot);
?>