                    
          
<div class="main-content">
    <form >
        <div class="form-group">
            <label>taluk</label>
            <select id="taluk" class="form-control"> <?php echo getTalukNameSelectList(); ?> </select>
        </div>
        <div class="form-group">
            <label >hobali</label>
            <select id="hobali" class="form-control"> <?php //echo gethobaliSelectList(); ?> </select>
        </div>
        <div class="form-group">
            <label>GM</label>
            <select id="gramapanchayat" class="form-control"> <?php echo getGPSelectList(); ?> </select>
        </div>
        <div class="form-group">
            <select id="village"> <?php echo getVillageselectlist(); ?> </select>
        </div>
<!--            <select id="gramapanchayath"> <?php echo getGramapanchayathNameSelectList(); ?> </select>
            <select id="village"> <?php echo getVillageNameSelectList(); ?> </select>-->
        

    </form>
</div>

<script>
    $("#taluk").change(function () { //Select Tag id  #taluk
        alert("abc");
        var id = $(this).val();
        var action = <?php echo HostRoot ?> + "assets/ajax/hobalis_by_taluk.php";
        $.post(action, {
            pid: id
        },
        function (data) {
            $("#hobali").empty().append(data.trim());
        });
    });
</script>