<?php
if (!empty($_SESSION['LBT_User'])) {
    redirect(HostRoot . "dashboard"); //If already logged in then redirect to dashboard
}

if (isset($_POST['PostInfo'])) {
    doLogin($_POST); //On submit check login Status
}
?>

<!DOCTYPE html>
<!-- Template Name: Clip-Two - Responsive Admin Template build with Twitter Bootstrap 3.x | Author: ClipTheme -->
<!--[if IE 8]><html class="ie8" lang="en"><![endif]-->
<!--[if IE 9]><html class="ie9" lang="en"><![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- start: HEAD -->
    <!-- start: HEAD -->
    <head>
        <title>Admin Control Panel</title>
        <!-- start: META -->
        <!--[if IE]><meta http-equiv='X-UA-Compatible' content="IE=edge,IE=9,IE=8,chrome=1" /><![endif]-->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- end: META -->
        <!-- start: GOOGLE FONTS -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <!-- end: GOOGLE FONTS -->
        <!-- start: MAIN CSS -->
        <link rel="stylesheet" href="<?php echo HostRoot; ?>vendor/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo HostRoot; ?>vendor/fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo HostRoot; ?>vendor/themify-icons/themify-icons.min.css">
        <link href="<?php echo HostRoot; ?>vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
        <link href="<?php echo HostRoot; ?>vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
        <link href="<?php echo HostRoot; ?>vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
        <!-- end: MAIN CSS -->
        <!-- start: CLIP-TWO CSS -->
        <link rel="stylesheet" href="<?php echo HostRoot; ?>assets/css/styles.css">
        <link rel="stylesheet" href="<?php echo HostRoot; ?>assets/css/plugins.css">
        <link rel="stylesheet" href="<?php echo HostRoot; ?>assets/css/themes/theme-1.css" id="skin_color" />
        <!-- end: CLIP-TWO CSS -->
        <!-- start: CSS REQUIRED FOR THIS PAGE ONLY -->
        <!-- end: CSS REQUIRED FOR THIS PAGE ONLY -->
        
        <style>
            body.login{
                /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#000000+0,000000+100&0+0,0.65+100 */
background: -moz-linear-gradient(top,  rgba(0,0,0,0) 0%, rgba(0,0,0,0.65) 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  rgba(0,0,0,0) 0%,rgba(0,0,0,0.65) 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  rgba(0,0,0,0) 0%,rgba(0,0,0,0.65) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#00000000', endColorstr='#a6000000',GradientType=0 ); /* IE6-9 */

            }
        </style>
    </head>
    <!-- end: HEAD -->
    <!-- start: BODY -->
    <body class="login">
        <!-- start: LOGIN -->
        <div class="row">
            <div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
                <div class="logo margin-top-30" align="center">
                    <img src="<?php echo HostRoot; ?>assets/images/karnataka_govt.png" alt="Clip-Two" style="width:120px"/>
                    <h4 style="color:#005c7c;">ಮಹಿಳಾ ಮತ್ತು ಮಕ್ಕಳ ಅಭಿವೃದ್ಧಿ ಇಲಾಖೆ</h4>
                    <h3 style="margin-bottom: 2px; color:#ff9900; font-weight:800">ನನ್ನ ನಡೆ ಶಾಲೆ ಕಡೆ</h3>
                </div>
                <!-- start: LOGIN BOX -->
                <div class="box-login">
                    <form class="form-login" action="<?php echo HostRoot . $page_name; ?>" method="post" onsubmit="return validate()">
                        <fieldset>
                            <legend>
                                Sign in to your account
                            </legend>
                            <p>
                                <?php echo getSessionMsg(); ?>
                            </p>
                            <div class="form-group">
                                <span class="input-icon">
                                    <input type="text" class="form-control" name="username" id="username" placeholder="Username">
                                    <i class="fa fa-user"></i>
                                </span>
                            </div>
                            <div class="form-group form-actions">
                                <span class="input-icon">
                                    <input type="password" class="form-control" name="password" placeholder="Password">
                                    <i class="fa fa-lock"></i>
<!--                                    <a class="forgot" href="javascript:void(0)">
                                        I forgot my password
                                    </a> -->
                                </span>
                            </div>
                            <div class="form-actions">
                                <!--								<div class="checkbox clip-check check-primary">
                                                                                                        <input type="checkbox" id="remember" value="1">
                                                                                                        <label for="remember">
                                                                                                                Keep me signed in
                                                                                                        </label>
                                                                                                </div>-->
                                <button type="submit" class="btn btn-primary pull-right" name="PostInfo">
                                    Login <i class="fa fa-arrow-circle-right"></i>
                                </button>
                            </div>
                            
                        </fieldset>
                    </form>
                    <!-- start: COPYRIGHT -->
                    <div class="copyright">
                        &copy; <span class="current-year"></span><span class="text-bold text-uppercase"> Zilla Panchayath, Udupi</span>. <span>All rights reserved</span>
                    </div>
                    <!-- end: COPYRIGHT -->
                </div>
                <!-- end: LOGIN BOX -->
            </div>
        </div>
        <!-- end: LOGIN -->
        <!-- start: MAIN JAVASCRIPTS -->
        <script src="<?php echo HostRoot; ?>vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/modernizr/modernizr.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/jquery-cookie/jquery.cookie.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
        <script src="<?php echo HostRoot; ?>vendor/switchery/switchery.min.js"></script>
        <!-- end: MAIN JAVASCRIPTS -->
        <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
        <script src="<?php echo HostRoot; ?>vendor/jquery-validation/jquery.validate.min.js"></script>
        <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
        <!-- start: CLIP-TWO JAVASCRIPTS -->
        <script src="<?php echo HostRoot; ?>assets/js/main.js"></script>
        <!-- start: JavaScript Event Handlers for this page -->
        <script src="<?php echo HostRoot; ?>assets/js/login.js"></script>
        <script>
                                    jQuery(document).ready(function () {
                                        jQuery("#username").focus();
                                        Main.init();
                                        Login.init();
                                    });
        </script>
        <!-- end: JavaScript Event Handlers for this page -->
        <!-- end: CLIP-TWO JAVASCRIPTS -->
    </body>
    <!-- end: BODY -->
</html>