<?php
    $ID = decode(strip_tags($_PID["profile"]));
    if(empty($ID) || !is_numeric($ID)){
        redirect(HostRoot."student_report");
    }
    $formData = getStudentByID($ID);
    $tqname = getTalukByID($formData["ef_taluk"]);
    $prefix = substr($tqname, 0,3);
    $st = ($formData['ef_status'] == 1) ? array("st"=>"2", "name"=>"Inactive") : array("st"=>"1", "name"=>"Active");
?>
<style>
    .dl-horizontal dt {width:165px !important; background-color: #99ccff; margin:1px auto; padding:2px; } 
    .dl-horizontal dd { margin-left: 170px !important; }
    .dl-horizontal {margin-bottom: 3px;}
    hr { margin-bottom: 3px; margin-top: 3px; }
</style>
<div class="main-content" >
    <div class="wrap-content container" id="container">
        <!-- start: PAGE TITLE -->
        <section id="page-title">
            <div class="row">
                <div class="col-sm-8">
                    <h1 class="mainTitle">ವಿದ್ಯಾರ್ಥಿ ಮಾಹಿತಿ</h1>
                </div>
                <ol class="breadcrumb">
                    <li>
                        <span>Dashboard</span>
                    </li>
                    <li class="active">
                        <span>Profile View</span>
                    </li>
                </ol>
            </div>
        </section>
        <?php echo getSessionMsg(); ?>
        <!-- start: FEATURED BOX LINKS -->
        <div class="container-fluid container-fullw bg-white clearfix" style="padding-top:10px;">

            <div class="panel panel-transparent">
                
                <div class="panel-heading">
                    <div class="panel-title">
                        <img src='<?php echo HostRoot?>assets/images/imgfiles/<?php echo $formData["ef_photo"]; ?>' class="thumbnail" style="height:100px; width:80px; position: absolute; right:0px;">

                        <span><strong class="text text-warning">ID: <?php echo strtoupper($prefix).$formData["ef_id"]; ?></strong></span><br />
                        <span><strong class="text text-warning">Name: <?php echo $formData["ef_name"]; ?></strong></span>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="row clearfix">
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>ಹೆಸರು </dt><dd><?php echo $formData["ef_name"]; ?></dd>
                                <dt>ವಯಸ್ಸು </dt><dd><?php echo $formData["ef_age"]; ?></dd>
                                <dt>ಜನ್ಮದಿನಾಂಕ</dt><dd><?php echo convertFromSqlDate($formData["ef_dob"]); ?></dd>
                                <dt>ತಂದೆಯ ಹೆಸರು </dt><dd><?php echo $formData["ef_fathername"]; ?></dd>
                                <dt>ತಾಯಿಯ ಹೆಸರು</dt><dd><?php echo $formData["ef_mothername"]; ?></dd>
                                <dt>ಪ್ರಸ್ತುತ ವಿಳಾಸ</dt><dd><?php echo $formData["ef_present_address"]; ?></dd>
                            </dl>
                        </div>
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>ಲಿಂಗ </dt><dd><?php echo $formData["ef_sex"]; ?></dd>
                                <dt>ಜಾತಿ </dt><dd><?php echo $formData["ef_cast"]; ?></dd>
                                <dt>ದೂರವಾಣಿ ಸಂಖ್ಯೆ </dt><dd><?php echo $formData["ef_contact"]; ?></dd>
                                <dt>ತಂದೆಯ ಉದ್ಯೋಗ</dt><dd><?php echo $formData["ef_fatheroccupation"]; ?></dd>
                                <dt>ತಾಯಿಯ ಉದ್ಯೋಗ </dt><dd><?php echo $formData["ef_motheroccupation"]; ?></dd>
                                <dt>ಖಾಯಂ ವಿಳಾಸ</dt><dd><?php echo $formData["ef_permanent_address"]; ?></dd>
                            </dl>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>ಪ್ರಸ್ತುತ ಕಲಿಯುತ್ತಿರುವ ತರಗತಿ </dt><dd><?php echo $formData["ef_study_class"]; ?></dd>
                                <dt>ತರಗತಿ ಶಿಕ್ಷಕರ ಹೆಸರು</dt><dd><?php echo $formData["ef_teacher_name"]; ?></dd>
                                <dt>ಮುಖ್ಯೋಪಾದ್ಯಾಯರ ಹೆಸರು</dt><dd><?php echo $formData["ef_headmaster_name"]; ?></dd>
                                <dt>ಅಂಗನವಾಡಿ ಕೇಂದ್ರ </dt><dd><?php echo $formData["ef_anganavadi_center"]; ?></dd>
                                <dt>ಅಂಗನವಾಡಿ ಕಾರ್ಯಕರ್ತೆಯ ಹೆಸರು</dt><dd><?php echo $formData["ef_anganavadi_teacher"]; ?></dd>
                                
                            </dl>
                        </div>
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>ಶಾಲೆಯ ಹೆಸರು</dt><dd><?php echo $formData["ef_school_name"]; ?></dd>
                                <dt>ತರಗತಿ ಶಿಕ್ಷಕರ ದೂರವಾಣಿ ಸಂಖ್ಯೆ </dt><dd><?php echo $formData["ef_teacher_contact"]; ?></dd>
                                <dt>ಮುಖ್ಯೋಪಾದ್ಯಾಯರ ದೂರವಾಣಿ ಸಂಖ್ಯೆ</dt><dd><?php echo $formData["ef_headmaster_contact"]; ?></dd>
                                <dt>ಶಾಲೆಯ ವಿಳಾಸ</dt><dd><?php echo $formData["ef_school_address"]; ?></dd>
                            </dl>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-md-4">
                            <dl class="dl-horizontal">
                                <dt>ಶಾಲೆ ಬಿಟ್ಟಿದೆ </dt><dd><?php echo ($formData["ef_quit_school"] == "yes") ? "ಹೌದು" : "ಇಲ್ಲ"; ?></dd>
                                <dt>ಶಾಲೆ ಬಿಟ್ಟ ದಿನಾಂಕ </dt><dd><?php echo convertFromSqlDate($formData["ef_quitting_date"]); ?></dd>
                                <dt>ಪುನಃ ಸೇರ್ಪಡೆಯಾದ ಶಾಲೆಯ ಹೆಸರು </dt><dd><?php echo $formData["ef_readmition_school_name"]; ?></dd>
                                <dt>ಎಷ್ಟು ದಿನ ಇಲ್ಲಿ ಇರುತ್ತಾರೆ   </dt><dd><?php echo $formData["ef_staying_days"]; ?></dd>
                                
                            </dl>
                        </div>
                        <div class="col-md-4">
                            <dl class="dl-horizontal">
                                <dt>ಶಾಲೆ ಬಿಟ್ಟಾಗ ತರಗತಿ</dt><dd><?php echo $formData["ef_quit_class"]; ?></dd>
                                <dt>ಎಷ್ಟು ದಿನ/ತಿಂಗಳು  </dt><dd><?php echo $formData["ef_numberofdays"]; ?></dd>
                                <dt>ಎಲ್ಲಿಂದ ವಲಸೆ</dt><dd><?php echo $formData["ef_immigrationfrom"]; ?></dd>
                                <dt>ಕೈಗೊಳ್ಳಬೇಕಾದ ಕ್ರಮಗಳು</dt><dd><?php echo $formData["ef_stepstobetaken"]; ?></dd>
                                
                            </dl>
                        </div>
                        <div class="col-md-4">
                            <dl class="dl-horizontal">
                                <dt>ಶಾಲೆ ಬಿಟ್ಟಾಗ ಶಾಲೆಯ ಹೆಸರು </dt><dd><?php echo $formData["ef_quit_school_name"]; ?></dd>
                                <dt>ಪುನಃ ಶಾಲೆಗೆ ಸೇರ್ಪಡೆಯಾಗಿದೆ </dt><dd><?php echo ($formData["ef_readmition"] == "yes") ? "ಹೌದು" : "ಇಲ್ಲ"; ?></dd>
                                <dt>ಎಲ್ಲಿಗೆ ಹೋಗುತ್ತಾರೆ  </dt><dd><?php echo $formData["ef_gotower"]; ?></dd>
                            </dl>
                        </div>
                    </div>
                    <hr />
                    <div class="clearfix">
                        <span class=" pull-right ">Last Update: <?php echo $formData["ef_updated_on"]; ?></span>
                        <a href='<?php echo HostRoot;?>entry_form/<?php echo encode($formData["ef_id"]); ?>' class="btn btn-primary"> <i class='fa fa-gears'></i> Edit</a>
                        <a href='<?php echo HostRoot;?>student_report/<?php echo encode($formData["ef_id"])."/st/".$st["st"]; ?>' class="btn btn-warning"> <i class='fa <?php echo $st["icon"]; ?>'></i> <?php echo $st["name"]; ?> </a>
                        
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel-title" align="center">
                                <h6>ಗೈರು ಹಾಜರಾದ ವಿವರ</h6>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ದಿನಾಂಕ</th>
                                            <th>ಹಾಜರಾತಿ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo getStudentAttendanceList($formData["ef_id"]); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>