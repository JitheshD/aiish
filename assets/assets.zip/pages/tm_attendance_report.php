<?php
$status = TRUE;
$year = $days = "";
if (isset($_POST["btnAttendReport"])) {
    $status = TRUE;
    $year = (isset($_POST["year"])) ? $_POST["year"] : "";
}
if (isset($_POST["btnAttendReportbyday"])) {
    $status = TRUE;
    $days = (isset($_POST["days"])) ? $_POST["days"] : "";
}
?>

<div class="container-fluid container-fullw bg-white">
    <div class="main-content">
        <div class="row">
            <div class="col-md-6">

                <fieldset>
                    <legend>
                        ಗೈರಾದ ವಿಧ್ಯಾರ್ಥಿಗಳ ವಾರ್ಷಿಕ ವರದಿ
                    </legend>
                    <div class="row">
                        <div class="panel-body">
                            <form role="form" method="post" class="form-horizontal">
                                <div class="col-md-8">
                                    <label class="col-sm-2 control-label" for="inputEmail3">
                                        ವರ್ಷ
                                    </label>
                                    <div class="col-sm-8">
                                        <input type="text" name="year" placeholder="YYYY" id="yyyy" name="yyyy" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary" name="btnAttendReport" type="submit">GO</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </fieldset>
            </div>
            <div class="col-md-6">

                <fieldset>
                    <legend>
                        ವಿದ್ಯಾರ್ಥಿ ದಿನಾಂಕ ವಾರು ಗೈರು ವಿವರ
                    </legend>
                    <div class="row">
                        <div class="panel-body">
                            <form role="form" method="post" class="form-horizontal">
                                <div class="col-md-8">
                                    <label class="col-sm-2 control-label" for="inputEmail3">
                                        ದಿನ
                                    </label>
                                    <div class="col-sm-8">
                                        <input type="text" name="days" placeholder="" name="days" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary" name="btnAttendReportbyday" type="submit">GO</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>
        <?php if($status){ ?>
        <div class="container-fluid container-fullw">
            
            <div class="table-responsive">
                <table class="table table-striped table-hover table-info">
                    <thead>
                        <tr>
                            <th>ಕ್ರಮ ಸಂಖ್ಯೆ</th>
                            <th>ವಿದ್ಯಾರ್ಥಿಯ ಹೆಸರು</th>
                            <th> ಒಟ್ಟು ಗೈರಾದ ದಿನ</th>
                            <th>ಶಾಲೆಯ ಹೆಸರು</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php //echo getAbsentReport($year); ?>
                        <?php echo getAbsentReportByDate($days, $year); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

