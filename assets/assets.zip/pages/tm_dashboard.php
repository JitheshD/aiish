
                
                <div class="main-content" >
                    <div class="wrap-content container" id="container">
                        <!-- start: DASHBOARD TITLE -->
                        <section id="page-title" class="padding-top-15 padding-bottom-15">
                            <div class="row">
                                <div class="col-sm-12">
                                    <h1 class="mainTitle">ಮುಖ್ಯ ಪುಟ</h1>
                                    <span class="mainDescription">ಮಹಿಳಾ ಮತ್ತು ಮಕ್ಕಳ ಕಲ್ಯಾಣ ಇಲಾಖೆ - <strong style="color:#ff9900;">ನನ್ನ ನಡೆ ಶಾಲೆ ಕಡೆ</strong></span>
                                </div>
                                <!--<div class="col-sm-5"></div>-->
                            </div>
                        </section>
                        <?php echo getSessionMsg(); ?>
                        <!-- end: DASHBOARD TITLE -->
                        <!-- start: FEATURED BOX LINKS -->
                        <div class="container-fluid container-fullw bg-white clearfix">
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="panel panel-white no-radius text-center">
                                        <div class="panel-body">
                                            <a href="<?php echo HostRoot;?>student_report">
                                                <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-newspaper-o fa-stack-1x fa-inverse"></i> </span>
                                                <h4 class="StepTitle">ಒಟ್ಟು ಮಕ್ಕಳು</h4>
                                            </a>
                                            <p class="links cl-effect-1">
                                                <a href="<?php echo HostRoot;?>student_report">
                                                    ವಿವರ
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="panel panel-white no-radius text-center">
                                        <div class="panel-body">
                                            <a href="<?php echo HostRoot; ?>attendance_report">
                                                <span class="fa-stack fa-2x"> <i class="fa fa-square fa-stack-2x text-primary"></i> <i class="fa fa-list fa-stack-1x fa-inverse"></i> </span>
                                                <h4 class="StepTitle">ಶಾಲಾ ಹಾಜರಾತಿ</h4>
                                            </a>
                                            <p class="cl-effect-1">
                                                <a href="<?php echo HostRoot; ?>attendance_report">
                                                    ವಿವರ
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <!-- end: FEATURED BOX LINKS -->
                        
                    </div>
                </div>
            