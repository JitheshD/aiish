<!-- start: CSS REQUIRED FOR THIS PAGE ONLY -->
		<link href="<?php echo HostRoot; ?>vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="<?php echo HostRoot; ?>vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="<?php echo HostRoot; ?>vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<!-- end: CSS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO CSS -->
		<link rel="stylesheet" href="<?php echo HostRoot; ?>assets/css/styles.css">
		<link rel="stylesheet" href="<?php echo HostRoot; ?>assets/css/plugins.css">
		<link rel="stylesheet" href="<?php echo HostRoot; ?>assets/css/themes/theme-1.css" id="skin_color" />
<div class="main-content">
    <div class="col-md-6">
        <h5 class="text-bold margin-top-25 margin-bottom-15">component</h5>
        <p class="input-group input-append datepicker date">
            <input type="text" class="form-control"/>
            <span class="input-group-btn">
            <button type="button" class="btn btn-default">
            <i class="glyphicon glyphicon-calendar"></i>
	</button> </span>
	</p>
	<h5 class="text-bold margin-top-25 margin-bottom-15">Format:</h5>
	<div class="form-group">
            <input class="form-control format-datepicker" type="text">
	</div>
    </div>
</div>
                
<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<!-- start: JavaScript Event Handlers for this page -->
                <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="<?php echo HostRoot; ?>vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="<?php echo HostRoot; ?>vendor/autosize/autosize.min.js"></script>
		<script src="<?php echo HostRoot; ?>vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="<?php echo HostRoot; ?>vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
                
		<script src="<?php echo HostRoot; ?>assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				FormElements.init();
			});
		</script>                